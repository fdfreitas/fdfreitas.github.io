// Circle.cpp: implementation of the CCircle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Circle.h"
#include <math.h>

#include <string>
using namespace std ;


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define Pi	3.1415926535897932384626433832795

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCircle::CCircle(UINT largura, COLORREF cor)
{
	m_crCor = cor ;
	m_nLargura = largura ;
//	CalcRect() ;
}

CCircle::~CCircle()
{
	//m_arrayPontos.RemoveAll() ;
}


void CCircle::SetarCor(COLORREF cor)
{
	m_crCor = cor ;
}

void CCircle::SetarLargura(UINT largura)
{
	m_nLargura = largura ;
}


void CCircle::SetP1(CPoint p)
{
	p1 = p ;
	CalcRect() ;
}

void CCircle::SetP1(UINT x, UINT y)
{
	p1.x = x ; p1.y = y ;
	CalcRect() ;
}

void CCircle::SetP2(CPoint p)
{
	p2 = p ;
	CalcRect() ;
}

void CCircle::SetP2(UINT x, UINT y)
{
	p2.x = x ; p2.y = y ;
	CalcRect() ;
}

CPoint CCircle::GetC(void)
{
	return c ;	
}


UINT CCircle::GetR(void)
{
	return r ;
}


void CCircle::CalcRect(void)
{
	CPoint _point ;

	// calcula coordenadas para o novo circulo
	int a = p2.y - p1.y ;
	int b = p2.x - p1.x ;

	// Calcula o raio do circulo em funccao do raio arrastado com o mouse
	int raio = 0.5 * sqrt (pow(a, 2) + pow (b, 2)) ;

	// Calcula o centro da circunferencia em funccao do raio arrastado com o mouse
	c.x = p1.x + b / 2 ;
	c.y = p1.y + a / 2 ; 
	r = raio ;
		
	// calcula os vertices do retangulo da circunferencia
	rect.SetRect (c.x - r, c.y - r, c.x + r, c.y + r) ;  	
}

void CCircle::Draw(CDC *pDC)
{

	// desenha a circunferencia
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 

	pDC->Ellipse(rect) ;

	pDC->SelectObject(pOldPen); 
}


#if 1 
IMPLEMENT_SERIAL(CCircle,CObject,1);

void CCircle::Serialize(CArchive &ar) {

    CObject::Serialize(ar);
    if(ar.IsStoring() ) {

	   ar << (ULONG) m_crCor << m_nLargura;
       ar << (ULONG) rect.TopLeft().x << rect.TopLeft().y <<
		      rect.BottomRight().x << rect.BottomRight().y ;       
    } 
	else 
	{ 
       ar >> (ULONG) m_crCor ;
	   ar >> m_nLargura;
	   UINT a, b, c, d ;

	   ar >> a ;
	   ar >> b ;
	   ar >> c ;
	   ar >> d ;		   

	   rect.SetRect (a, b, c, d) ;  	       
	   	   
    } 
}

#endif



#if 0
// Poligonal.cpp: implementation of the CPoligonal class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Poligonal.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPoligonal::CPoligonal(UINT largura, COLORREF cor)
{
	m_crCor = cor ;
	m_nLargura = largura ;
	m_arrayPontos.SetSize(0,10) ;
}


CPoligonal::~CPoligonal()
{
	m_arrayPontos.RemoveAll() ;
}

void CPoligonal::SetarCor(COLORREF cor)
{
	m_crCor = cor ;
}

void CPoligonal::SetarLargura(UINT largura)
{
	m_nLargura = largura ;
}

void CPoligonal::AdicionarPonto(CPoint ponto)
{
	m_arrayPontos.Add(ponto) ;
}

void CPoligonal::Draw(CDC *pDC)
{
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 

	int ncount = m_arrayPontos.GetSize(); 

	if( ncount > 1 ) { 
		CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 
		pDC->MoveTo(m_arrayPontos[0]); 
		for(int i=1;i<ncount;i++) { 
		    pDC->LineTo(m_arrayPontos[i]); 
		}; 
		pDC->SelectObject(pOldPen); 
	}; 
}

 IMPLEMENT_SERIAL(CPoligonal,CObject,1);

 void 
 CPoligonal::Serialize(CArchive &ar) {

    CObject::Serialize(ar);
    if(ar.IsStoring() ) {
       ar << (ULONG) m_crCor << m_nLargura;
       UINT size = m_arrayPontos.GetSize();
       ar << size;
       for(UINT i=0;i<size;i++) {
          CPoint p = m_arrayPontos[i];
          ar << p.x << p.y;
       };
    } else { 
       ULONG cor;
       ar >>  cor;
       m_crCor = (COLORREF) cor;
       ar >> m_nLargura;
       UINT size;
       ar >> size;
       for(UINT i=0;i<size;i++) {
          CPoint p;
          ar >> p.x >> p.y;
          m_arrayPontos.Add(p);
       };
    }; 
 }


Rectangle



/*
	if ( r > 0 )
	{
		_point = c ;
		_point.Offset (r, 0) ;
		
		for ( double i = 0.0; i <= 360.0; i+= 4.0 )
		{
			double angulo = i * 2.0 * Pi / 360.0 ;
			double rsin = r * sin (angulo) ;
			double rcos = r * cos (angulo) ;

			pDC->MoveTo(_point); 
			_point.x = c.x + (int) rcos ; 
			_point.y = c.y + (int) rsin ;
			pDC->LineTo (_point) ;
		}
*/

/*
		CRect rect ;
		
		rect.SetRect( 260, 260, 560, 300);

		pDC->TextOut( 290, 290, s.c_str(), s.length());		
		pDC->DrawText( "F�bio", 5, &rect, DT_CALCRECT | DT_NOCLIP  );

	}
*/

#endif