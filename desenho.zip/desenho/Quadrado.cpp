// Quadrado.cpp: implementation of the CQuadrado class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Quadrado.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CQuadrado::CQuadrado()
{
	SetQuadrado() ;
}

CQuadrado::~CQuadrado()
{

}

void CQuadrado::SetP1(CPoint p)
{
	p1 = p ;
	// calcula o retangulo a partir dos pontos
	CalcRect() ;
}

void CQuadrado::SetP2(CPoint p)
{
	p2 = p ;
	// calcula o retangulo a partir dos pontos
	CalcRect() ;
}

void CQuadrado::SetQuadrado()
{
	m_tipo = Q_QUADRADO ;	
}

void CQuadrado::SetRetangulo()
{
	m_tipo = Q_RETANGULO ;
}

void CQuadrado::CalcRect(void)
{
	CPoint _point ;

	if ( m_tipo == Q_QUADRADO )
	{		
		// calcula coordenadas para o novo quadrado
		int a = p2.y - p1.y ;
		int b = p2.x - p1.x ;

		// Acha a maior dimensao tamanho do maior lado do quadrado em funccao do ponto 
		// arrastado com o mouse, sempre usando P1 como vertice, e calcula os vertices
	
		int l = (abs(a) >= abs(b)? abs (a): abs(b)) ;
		int x = p1.x ;
		int y = p1.y ;

		if ( a < 0 )	y -= l ;
		if ( b < 0 )	x -= l ; 

		rect.SetRect (x, y, x + l, y + l) ;  	
	}
	else if ( m_tipo == Q_RETANGULO )
	{		
		rect.SetRect (p1.x, p1.y, p2.x, p2.y) ;  	
	}
}

void CQuadrado::Draw(CDC *pDC)
{	
	// desenha a circunferencia
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 

	pDC->SetROP2(R2_COPYPEN); 

	pDC->Rectangle (rect) ;

	pDC->SelectObject(pOldPen); 
}


void CQuadrado::UnDraw(CDC *pDC)
{
	// desenha a circunferencia
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 

	pDC->SetROP2(R2_NOTXORPEN); 

	pDC->Rectangle (rect) ;

	pDC->SelectObject(pOldPen); 
}


IMPLEMENT_SERIAL(CQuadrado,CObject,1);

void CQuadrado::Serialize(CArchive &ar) {

    CObject::Serialize(ar);
    if(ar.IsStoring() ) {

	   ar << (ULONG) m_crCor << m_nLargura;
       ar << (ULONG) rect.TopLeft().x << rect.TopLeft().y <<
		      rect.BottomRight().x << rect.BottomRight().y ;       
    } 
	else 
	{ 
       ar >> (ULONG) m_crCor ;
	   ar >> m_nLargura;
	   UINT a, b, c, d ;

	   ar >> a ;
	   ar >> b ;
	   ar >> c ;
	   ar >> d ;		   

	   rect.SetRect (a, b, c, d) ;  	       
	   	   
    } 
}

// EOF
