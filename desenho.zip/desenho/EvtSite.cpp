// Site.cpp: implementation of the CEvtSite class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "EvtSite.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEvtSite::CEvtSite()
{

}


CEvtSite::CEvtSite(CEvtSite *s)
{
	p1 = s->GetP1() ;
	p2 = s->GetP2() ;
}


CEvtSite::CEvtSite(CPoint p)
{
	p1 = p ;
	p2 = p ;
}


CEvtSite::CEvtSite(CObjDes *e)
{
}


CEvtSite::~CEvtSite()
{

}

// EOF