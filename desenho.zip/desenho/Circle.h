// Circle.h: interface for the CCircle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CIRCLE_H__BCEB93DD_5376_4BA2_B1E0_0E78F42C47D2__INCLUDED_)
#define AFX_CIRCLE_H__BCEB93DD_5376_4BA2_B1E0_0E78F42C47D2__INCLUDED_

#include "Objdes.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//class CObjDes ;

class CCircle : public CObjDes
{
public:
//    void AdicionarPonto(CPoint ponto);
    void SetarLargura(UINT largura);
    void SetarCor(COLORREF cor);
	void SetP1(CPoint p);
	void SetP1(UINT x, UINT y);
	void SetP2(CPoint p);
	void SetP2(UINT x, UINT y);
	CPoint GetC(void);
	UINT GetR(void);
	void Draw(CDC *pDC);

	CCircle(UINT largura=1, COLORREF cor =RGB(0,0,0) );
	virtual ~CCircle();
    
   virtual void Serialize(CArchive &ar);
   DECLARE_SERIAL(CCircle); 

 protected:
	void CCircle::CalcRect(void);
    COLORREF m_crCor;
    UINT m_nLargura; 

	CPoint p1; 
	CPoint p2; 
	CPoint c; 
	UINT r; 
	CRect rect; 

};

#endif // !defined(AFX_CIRCLE_H__BCEB93DD_5376_4BA2_B1E0_0E78F42C47D2__INCLUDED_)



#if 0
class CPoligonal : public CObject 
 {
 public:
    void AdicionarPonto(CPoint ponto);
    void SetarLargura(UINT largura);
    void SetarCor(COLORREF cor);
    void Draw(CDC *pDC);
    CPoligonal(UINT largura=1, COLORREF cor =RGB(0,0,0) );
    virtual ~CPoligonal();

    virtual void Serialize(CArchive &ar);
    DECLARE_SERIAL(CPoligonal); 

 protected:
    CArray<CPoint, CPoint &> m_arrayPontos;
    COLORREF m_crCor;
    UINT m_nLargura; 
 };
#endif