// Edge.cpp: implementation of the CEdge class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Edge.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEdge::CEdge()
{
	linha.SetarCor(RGB (0,0, 255)) ;

	orig  = NULL ;	// Vertice origem 
	dest  = NULL ;	// Vertice destino 
	twin  = NULL ;	// Edge gemeo 	
	prev  = NULL ;	// Edge anterior da face esquerda no sentido anti-horario
	next  = NULL ;	// Edge posterior da face esquerda no sentido anti-horario
	left  = NULL ;	// Face esquerda do edge

	left_site   = NULL ;	// site esquerda do edge	

	drawable = true;
}

CEdge::CEdge(CPlane *p)
{

	Plano = p ;

	linha.SetarCor(RGB (0, 0,255)) ;

	orig  = NULL ;	// Vertice origem 
	dest  = NULL ;	// Vertice destino 
	twin  = NULL ;	// Edge gemeo 	
	prev  = NULL ;	// Edge anterior da face esquerda no sentido anti-horario
	next  = NULL ;	// Edge posterior da face esquerda no sentido anti-horario
	left  = NULL ;	// Face esquerda do edge

	left_site   = NULL ;	// site esquerda do edge	

	drawable = true;
}


CEdge::~CEdge()
{

}

CEdge *CEdge::This()
{
	return this;
}

void CEdge::SetOrig(CVertex *v)
{
	if ( v != NULL )
	{
		orig = v ;
		pontos.first.x = v->GetPoint().x ;
		pontos.first.y = v->GetPoint().y ;
	}
}

void CEdge::SetOrig(DPoint p)
{
	pontos.first = p ;
}


CVertex *CEdge::GetOrig()
{
	return orig ;
}

DPoint CEdge::GetPointOrig()
{
	return pontos.first ;
}


void CEdge::SetDest(CVertex *v)
{
	if ( v != NULL )
	{
		dest = v ;
		pontos.second.x = v->GetPoint().x ;
		pontos.second.y = v->GetPoint().y ;
	}
}

void CEdge::SetDest(DPoint p)
{
	pontos.second = p ;
}


CVertex *CEdge::GetDest()
{
	return dest;
}


DPoint CEdge::GetPointDest()
{
	return pontos.second ;
}


void CEdge::SetTwin(CEdge *e)
{
	twin = e ;

	if ( GetOrig() != NULL )
		e->SetDest(GetOrig());
	else
		e->SetDest(GetPointOrig());

	if ( GetDest() != NULL )
		e->SetOrig(GetDest());
	else
		e->SetOrig(GetPointDest());

	// PODEM SER NULL
	SetPrev(e->GetNext());
	SetNext(e->GetPrev());

	// tratar a face...

	// inibe o desenho do twin!!!
	e->SetDrawable( !IsDrawable() );

}

CEdge *CEdge::GetTwin()
{
	return twin ;
}

void CEdge::SetPrev(CEdge *e)
{
	prev = e ;
}

CEdge *CEdge::GetPrev()
{
	return prev ;
}

void CEdge::SetNext(CEdge *e)
{
	next = e ;
}

CEdge *CEdge::GetNext()
{
	return next ;
}

void CEdge::SetFacet(CFacet *f)
{
	left = f ;
}

CFacet *CEdge::GetFacet()
{
	return left  ;
}


void CEdge::SetLeftSite(CEvtSite *s)
{


	left_site = new CEvtSite (s) ;
}

CEvtSite *CEdge::GetLeftSite()
{
	return left_site ;
}



void CEdge::SetPoints(pair<DPoint,DPoint> p)
{

	SetOrig(p.first) ;
	SetDest (p.second) ;
}

pair<DPoint,DPoint> CEdge::GetPoints()
{
	return pontos; ;
}

void CEdge::SetDrawable(bool b)
{
	drawable = b ;
}

bool CEdge::IsDrawable()
{
	return drawable ;
}

void CEdge::Draw()
{

	// tenho que fazer o meu Draw pois podem existir 2 edges na mesm posiccao
	// entao com o R2_NOTXORPEN, um apaga o outro!!!!!

	if ( IsDrawable() )
	{

		UnDraw();

		CPoint p ;

		if ( pontos.first.x <= (double)(MIN_INT) )
			p.x = MIN_INT;
		else if ( pontos.first.x >= (double)(MAX_INT) )
			p.x = MAX_INT;
		else
			p.x = (int) (pontos.first.x + 0.5) ;

		
		if ( pontos.first.y <= (double)(MIN_INT) )
			p.y = MIN_INT;
		else if ( pontos.first.y >= (double)(MAX_INT) )
			p.y = MAX_INT;
		else
			p.y = (int) (pontos.first.y + 0.5) ;

		linha.SetP1(p) ;

		if ( pontos.second.x <= (double)(MIN_INT) )
			p.x = MIN_INT;
		else if ( pontos.second.x >= (double)(MAX_INT) )
			p.x = MAX_INT;
		else
			p.x = (int) (pontos.second.x + 0.5) ;

		
		if ( pontos.second.y <= (double)(MIN_INT) )
			p.y = MIN_INT;
		else if ( pontos.second.y >= (double)(MAX_INT) )
			p.y = MAX_INT;
		else
			p.y = (int) (pontos.second.y + 0.5) ;


		linha.SetP2(p) ;
	
		linha.Draw(Plano->pDC) ;
	
		pontos_.first = pontos.first ;
		pontos_.second= pontos.second ;
	}
}


void CEdge::UnDraw()
{

	CPoint p ;
	if ( pontos_.first.x <= (double)(MIN_INT) )
		p.x = MIN_INT;
	else if ( pontos_.first.x >= (double)(MAX_INT) )
		p.x = MAX_INT;
	else
		p.x = (int) (pontos_.first.x + 0.5) ;
		
	if ( pontos_.first.y <= (double)(MIN_INT) )
		p.y = MIN_INT;
	else if ( pontos_.first.y >= (double)(MAX_INT) )
		p.y = MAX_INT;
	else
		p.y = (int) (pontos_.first.y + 0.5) ;
		
	linha.SetP1(p) ;


	if ( pontos_.second.x <= (double)(MIN_INT) )
		p.x = MIN_INT;
	else if ( pontos_.second.x >= (double)(MAX_INT) )
		p.x = MAX_INT;
	else
		p.x = (int) (pontos_.second.x + 0.5) ;
		
	if ( pontos_.second.y <= (double)(MIN_INT) )
		p.y = MIN_INT;
	else if ( pontos_.second.y >= (double)(MAX_INT) )
		p.y = MAX_INT;
	else
		p.y = (int) (pontos_.second.y + 0.5) ;

	linha.SetP2(p) ;

	// desenha a linha
	linha.UnDraw(Plano->pDC) ;
}


// EOF
