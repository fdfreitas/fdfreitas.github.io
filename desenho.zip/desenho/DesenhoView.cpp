// DesenhoView.cpp : implementation of the CDesenhoView class
//

#include "stdafx.h"
#include "Desenho.h"

#include <string>
using namespace std ;

#include "DesenhoDoc.h"
#include "DesenhoView.h"

//#include <afxcmn.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CDesenhoView

IMPLEMENT_DYNCREATE(CDesenhoView, CScrollView)

BEGIN_MESSAGE_MAP(CDesenhoView, CScrollView)
	//{{AFX_MSG_MAP(CDesenhoView)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_TOOLS_FREEHAND, OnToolsFreehand)
	ON_COMMAND(ID_TOOLS_POLIGONAL, OnToolsPoligonal)
	ON_COMMAND(ID_TOOLS_RETANGULO, OnToolsRetangulo)
	ON_COMMAND(ID_TOOLS_CIRCULO, OnToolsCirculo)
	ON_COMMAND(ID_TOOLS_TEXTO, OnToolsTexto)
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_TOOLS_LINHA, OnToolsLinha)
	ON_COMMAND(ID_TOOLS_REFRESH, OnToolsRefresh)
	ON_COMMAND(ID_TOOLS_PONTO, OnToolsPonto)
	ON_COMMAND(ID_DELAUNAY_START, OnDelaunayStart)
	ON_COMMAND(ID_DELAUNAY_STOP, OnDelaunayStop)
	ON_COMMAND(ID_DELAUNAY_CLEAR, OnDelaunayClear)
	ON_COMMAND(ID_DELAUNAY_Y_STEP, OnDelaunayYStep)
	ON_COMMAND(ID_DELAUNAY_EVENT_STEP, OnDelaunayEventStep)
	ON_COMMAND(ID_DELAUNAY_SHOW_VORONOI, OnDelaunayShowVoronoi)
	ON_COMMAND(ID_DELAUNAY_SHOW_DELAUNAY, OnDelaunayShowDelaunay)
	ON_COMMAND(ID_DELAUNAY_SHOW_BEACH, OnDelaunayShowBeach)
	ON_COMMAND(ID_DELAUNAY_SHOW_CIRCLE, OnDelaunayShowCircle)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDesenhoView construction/destruction

CDesenhoView::CDesenhoView()
{
	m_pFerramenta = new CFerramenta ;
	m_pDelaunay   = new CDelaunay () ;
	DELAUNAY_STEP = false ;
}

CDesenhoView::~CDesenhoView()
{
	if ( m_pFerramenta ) delete m_pFerramenta ; 
	if ( m_pDelaunay ) 	 delete m_pDelaunay ; 
}

BOOL CDesenhoView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDesenhoView drawing

void CDesenhoView::OnDraw(CDC* pDC)
{
	CDesenhoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

	UINT n = pDoc->GetSize(); 
	for(UINT i=0;i<n;i++) { 
		((CObjDes *)pDoc->Get(i))->Draw(pDC); 
	}
	
	// Redesenha o modulo Delaunay....
	m_pDelaunay->ReDraw();

}

void CDesenhoView::OnInitialUpdate()
{
    CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
    sizeTotal.cx = sizeTotal.cy = 1000;
    SetScrollSizes(MM_TEXT, sizeTotal);

	pDC		= 	new CClientDC (this); 
	m_pDelaunay->SetDC(pDC);
	m_pDelaunay->SetDoc(GetDocument());
 }


/////////////////////////////////////////////////////////////////////////////
// CDesenhoView printing

BOOL CDesenhoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDesenhoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CDesenhoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CDesenhoView diagnostics

#ifdef _DEBUG
void CDesenhoView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CDesenhoView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CDesenhoDoc* CDesenhoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDesenhoDoc)));
	return (CDesenhoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDesenhoView message handlers

void CDesenhoView::OnLButtonDown(UINT nFlags, CPoint point)  
{
	m_pFerramenta->OnLButtonDown(GetDocument(), pDC, nFlags, point) ;
	CScrollView::OnLButtonDown(nFlags, point); 
} 

void CDesenhoView::OnMouseMove(UINT nFlags, CPoint point)  
{ 	
	m_pFerramenta->OnMouseMove(GetDocument(), pDC, nFlags, point) ;	
	CScrollView::OnMouseMove(nFlags, point); 
} 

void CDesenhoView::OnLButtonUp(UINT nFlags, CPoint point)  
{ 
	m_pFerramenta->OnLButtonUp (GetDocument(), pDC, nFlags, point) ;
	CScrollView::OnLButtonUp(nFlags, point); 
} 

void CDesenhoView::OnLButtonDblClk(UINT nFlags, CPoint point)  
{ 
	m_pFerramenta->OnLButtonDblClk(GetDocument(), pDC, nFlags, point) ;  
	CScrollView::OnLButtonDblClk(nFlags, point); 

}

void CDesenhoView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if ( DELAUNAY_STEP )
		m_pDelaunay->StepY() ;	
	else
	{
		m_pFerramenta->OnKeyDown(GetDocument(), pDC, nChar, nRepCnt, nFlags) ;
		CScrollView::OnKeyDown(nChar, nRepCnt, nFlags);

		/* BUG!!! nao estava redesenhando o texto vazio!!!! */
		if ( nChar == VK_ESCAPE ) this->Invalidate();
	}
}


void CDesenhoView::OnToolsRefresh() 
{
	OnDraw(pDC) ;
}

void CDesenhoView::OnToolsFreehand() 
{
	m_pFerramenta->SetTipoDesenho (FREEHAND);
}

void CDesenhoView::OnToolsPoligonal() 
{
	m_pFerramenta->SetTipoDesenho (POLIGONAL); 	
}

void CDesenhoView::OnToolsRetangulo() 
{
	m_pFerramenta->SetTipoDesenho (RETANGULO); 	
}

void CDesenhoView::OnToolsCirculo() 
{
	m_pFerramenta->SetTipoDesenho (CIRCULO); 	
}

void CDesenhoView::OnToolsLinha() 
{
	m_pFerramenta->SetTipoDesenho (LINHA); 		
}

void CDesenhoView::OnToolsTexto() 
{
	m_pFerramenta->SetTipoDesenho (TEXTO); 		
}


void CDesenhoView::OnToolsPonto() 
{
	m_pFerramenta->SetTipoDesenho (PONTO); 		
	
}

// DELAUNAY
void CDesenhoView::OnDelaunayStart() 
{
	DELAUNAY_STEP = false ;
	m_pDelaunay->Run() ;	
}

void CDesenhoView::OnDelaunayStop() 
{
	m_pDelaunay->Suspend() ;		
}

void CDesenhoView::OnDelaunayYStep() 
{
	//m_pDelaunay->StepY() ;	

	DELAUNAY_STEP = true ;
	m_pDelaunay->StepY() ;	
	//m_pDelaunay->Run() ;	
}

void CDesenhoView::OnDelaunayEventStep() 
{
	DELAUNAY_STEP = true ;
//	m_pDelaunay->StepEvent() ;	
}


void CDesenhoView::OnDelaunayClear() 
{
	DELAUNAY_STEP = false ;
	m_pDelaunay->Reset() ;	
	
}

void CDesenhoView::OnDelaunayShowVoronoi() 
{
	m_pDelaunay->SetShowVoronoi() ;	
}

void CDesenhoView::OnDelaunayShowDelaunay() 
{
	m_pDelaunay->SetShowDelaunay() ;		
}

void CDesenhoView::OnDelaunayShowBeach() 
{
	m_pDelaunay->SetShowBeach() ;		
}

void CDesenhoView::OnDelaunayShowCircle() 
{
	m_pDelaunay->SetShowCircle() ;		
}


// EOF
