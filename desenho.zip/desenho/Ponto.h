// Ponto.h: interface for the CPonto class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PONTO_H__882AD5EB_D206_4D03_AEE3_F70FC5071508__INCLUDED_)
#define AFX_PONTO_H__882AD5EB_D206_4D03_AEE3_F70FC5071508__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ObjDes.h"

class CPonto : public CObjDes  
{
public:
	CPonto();
	CPonto(CPoint p);
	virtual ~CPonto();
	void SetP1(CPoint p);
	CPoint GetP1();
	void CalcRect(void);
	void Draw(CDC *pDC); 
	void UnDraw(CDC *pDC);
	virtual void Serialize(CArchive &ar);
    DECLARE_SERIAL(CPonto); 

protected:
	CRect rect; 
};

#endif // !defined(AFX_PONTO_H__882AD5EB_D206_4D03_AEE3_F70FC5071508__INCLUDED_)


// EOF
