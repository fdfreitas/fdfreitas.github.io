///////////////////////////////////////////////////////////////////////////////
// @@ PromoteOpenEdges()
// Cria vertices nos limites do planos para os edges abertos.
///////////////////////////////////////////////////////////////////////////////
void BeachLine::PromoteOpenEdges()
{
	list<CEdge>::iterator first = edgelist.begin();
	list<CEdge>::iterator last  = edgelist.end();
	list<CEdge>::iterator found = first ;

	pair<DPoint, DPoint> pontos ;
	CVertex *v ;
	CEdge *e;

	while ( found != last )
	{
		e = found->This() ;
		pontos = edge->GetPontos();
	  	if ( e->GetOrig() == NULL )
		{
			v = AddVertex(pontos.first, e);
			PromoteVertex (v, edge) ;
			edge->SetOrig(v) ;
		} 
		else  if ( e->GetDest() == NULL )
		{
			v = AddVertex(pontos.second, e);
			PromoteVertex (v, edge) ;
			edge->SetDest(v) ;
		} 
	}
}

///////////////////////////////////////////////////////////////////////////////
// @@ PromoteVertex()
// Ajusta o vertice para dentro dos limites do plano.
///////////////////////////////////////////////////////////////////////////////
void BeachLine::PromoteVertex(CVertex *v, CEdge *edge)
{
	pair<DPoint, DPoint> pontos ;
	CPoint p;

 	// acha a equaccao do edge: y = Ax + B, x = (y - B)/A
	pontos = edge->GetPontos();
	double A = (pontos.second.y - pontos.first.y)/(pontos.second.x - pontos.first.x); 
	double B = pontos.first.y/(A*pontos.first.x); 

	// calcula o novo ponto do vertice
	switch (ExtrapoledQuadrant(v))
	{
		// O vertice esta dentro do plano!
		case 0:
			return;
		// quadrante 1
		case 1:
			p.x = Plano->UL.x;
			p.y = (int)(A*p.x + B) ;
			break;
		// quadrante 2
		case 2:
			p.y = Plano->UL.y ;
			p.x = (int)((p.y - B)/A);
			break;
		// quadrante 3
		case 3:
			p.x = Plano->LR.x;
			p.y = (int)(A*p.x + B) ;
			break;
		// quadrante 4
		case 4:
			p.y = Plano->LR.y ;
			p.x = (int)((p.y - B)/A);
			break;			
	}
	// ajusta o vertice
	v->SetP1(p) ;
}

///////////////////////////////////////////////////////////////////////////////
// @@ ExtrapoledQuadrant()
// Retorna o quadrante extrapolado pelo vertice.
//       2     
//   +-------+
//   |       |
// 1 |   0   | 3
//   |       |
//   +-------+
//       4
///////////////////////////////////////////////////////////////////////////////
int BeachLine::ExtrapoledQuadrant(CVertex *v)
{
	// Quadrante 1 
	if ( v->GetP1().x < Plano->UL.x &&
           v->GetP1().y >= Plano->UL.y && v->GetP1().y <= Plano->LR.y )
	    return 1 ;

	// Quadrante 2 
	if ( v->GetP1().x >= Plano->UL.x && v->GetP1().x <= Plano->LR.x
           v->GetP1().y < Plano->UL.y )
	    return 2 ;

	// Quadrante 3 
	if ( v->GetP1().x > Plano->LR.x &&
           v->GetP1().y >= Plano->UL.y && v->GetP1().y <= Plano->LR.y )
	    return 3 ;

	// Quadrante 4 
	if ( v->GetP1().x >= Plano->UL.x && v->GetP1().x <= Plano->LR.x
           v->GetP1().y > Plano->LR.y )
	    return 4 ;

	return 0 ;
}
