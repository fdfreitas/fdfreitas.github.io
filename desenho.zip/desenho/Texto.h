// Texto.h: interface for the CTexto class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXTO_H__2754E189_4F0D_4B32_B789_EB54C496B4E7__INCLUDED_)
#define AFX_TEXTO_H__2754E189_4F0D_4B32_B789_EB54C496B4E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ObjDes.h"
#include <string>
using namespace std ;

class CTexto : public CObjDes  
{
public:
	CTexto();
	virtual ~CTexto();
	void SetP1(CPoint p);
	void SetTexto(UINT c);
	void SetTexto(CString s);
	void ClearTexto();	
	void Draw(CDC *pDC); 
	void UnDraw(CDC *pDC);
	virtual void Serialize(CArchive &ar);
    DECLARE_SERIAL(CTexto); 
 protected:
	CString texto ; 
};

#endif // !defined(AFX_TEXTO_H__2754E189_4F0D_4B32_B789_EB54C496B4E7__INCLUDED_)
