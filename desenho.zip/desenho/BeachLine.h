// BeachLine.h: interface for the CBeachLine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BEACHLINE_H__10CCF870_0B25_4281_8B05_FD2FFBA2B336__INCLUDED_)
#define AFX_BEACHLINE_H__10CCF870_0B25_4281_8B05_FD2FFBA2B336__INCLUDED_


#include "Plane.h"
#include "ParArc.h"
#include "EventQueue.h"
#include "Evt.h"
#include "EvtSite.h"
#include "EvtCircle.h"

#include "Edge.h"
#include "Vertex.h"
#include "Facet.h"

#include <set>
#include <list>

using namespace std ;

typedef CPoint point ;

typedef double** Matrix;
typedef double*  Vector;

#define        ABS(x)   ((x) < 0.0 ? -(x) : (x))
#define        SIGN(x)  ((x) < 0.0 ? (-1) : (1))


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CBeachLine : public CObject  
{
public:
	CBeachLine();
	CBeachLine(CPlane *p);
	virtual ~CBeachLine();
	void Clear ();
	void SetPlane(CPlane *plano);
	void Setup(CEventQueue *q,list<CEdge> *e,list<CVertex> *v,list<CFacet> *f);
	void SetY(int y);
	int GetY();
	CParArc *FindArcAbove(CParArc *a);
	multiset<CParArc>::iterator FindArcIterator(CParArc *a);
	multiset<CParArc>::iterator FindEvtCircleArcIterator(CEvtCircle *e, CParArc *a);
	void Draw();
	void UnDraw();

	CParArc *Add(CEvtSite *e);
	void CalcBreakPoints();
	bool BPInPlane(DPoint p);
	bool AllBPOutOfPlane();
	bool CanStopSweep();
	CEvtCircle *CalcCircleEvents (multiset<CParArc>::iterator it_arco_inicial);
	double OrientationTest(multiset<CParArc>::iterator it_arco_inicial);
	void AddEvtCircle(CEvtCircle *c);

	// Metodos manipuladores das estruturas de dados....
	//CEdge  *AddEdge(DPoint bp_orig, DPoint bp_dest);
	CEdge *AddEdge(DPoint bp_orig, DPoint bp_dest, CEvtSite *s_l, CEvtSite *s_r);
	CVertex *AddVertex(DPoint center, CEdge *e);
	CVertex *AddVertex(DPoint center, CEdge *e, vertextype t);
	CFacet *AddFacet(CEvtSite *s);
	void HandleVertex(CEvtCircle *ecircle, CParArc *a, CParArc *f, CParArc *p);

		// Metodos principais
	CParArc *HandleSiteEvent (CEvtSite *e);
	void HandleCircleEvent   (CEvtCircle *e);

	// solver...
	Matrix CreateMatrix(int l, int r);
	void DestroyMatrix(int l, Matrix a);	
	Vector CreateVector(int r);
	void DestroyVector(Vector a);
	void Solve(Matrix gk, int nnodes, Vector gf, Vector x);

	void SetShowCircle(bool b);
	void SetShowBeach(bool b);

	void Debug();
	void Debug( char *s);

protected:
	
	CPlane *Plano;					// Plano....
	int Y ;							// Posiccao atual da SweepLine
	multiset<CParArc>	parcs ;		// Arcos parabolicos da Beach Line
	CEventQueue			*equeue ;	// Ponteiro para a Fila de eventos
	list<CEdge>			*edgelist;	// Ponteiro para a lista de arestas
	list<CVertex>		*vertexlist;// Ponteiro para a lista de vertices
	list<CFacet>		*facetlist;	// Ponteiro para a lista de faces
	bool all_bp_out_of_plane;		// Flag dex out of plane dos BPs - criterio de parada
	bool show_circle;
	bool show_beach;

};

#endif // !defined(AFX_BEACHLINE_H__10CCF870_0B25_4281_8B05_FD2FFBA2B336__INCLUDED_)


