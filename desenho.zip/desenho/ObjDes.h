// ObjDes.h: interface for the CObjDes class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OBJDES_H__82860728_241A_4601_BD0C_DED759DD9290__INCLUDED_)
#define AFX_OBJDES_H__82860728_241A_4601_BD0C_DED759DD9290__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CObjDes : public CObject  
{
public:
	CObjDes(UINT largura=1, COLORREF cor =RGB(0,0,0) );
	CObjDes(CPoint p) ;
	virtual ~CObjDes();
    void SetarCor(COLORREF cor);
	COLORREF CObjDes::GetCor() ;
    void SetarLargura(UINT largura);
    UINT GetLargura();

	// implementaccoes obrigatorias na classe derivada
	virtual void SetP1(CPoint p);
	CPoint CObjDes::GetP1();
	virtual void SetP2(CPoint p);
	CPoint CObjDes::GetP2();
	virtual void Draw(CDC *pDC);
	virtual void UnDraw(CDC *pDC);

	// Seccao NICE CLASS!!! 

	CObjDes(const CObjDes& o) 
	{		
	    m_crCor = o.m_crCor;
		m_nLargura = o.m_nLargura; 
		p1 = o.p1; 
		p2 = o.p2;
	}

	CObjDes& operator= (const CObjDes& o) 
	{
	    m_crCor = o.m_crCor;
		m_nLargura = o.m_nLargura; 
		p1 = o.p1; 
		p2 = o.p2;

		return *this;
	}

	// fim NICE CLASS!!!!  


protected:
    COLORREF m_crCor;
    UINT m_nLargura; 
	CPoint p1; 
	CPoint p2;
};

#endif // !defined(AFX_OBJDES_H__82860728_241A_4601_BD0C_DED759DD9290__INCLUDED_)
// EOF