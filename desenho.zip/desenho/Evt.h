// Evt.h: interface for the CEvt class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EVT_H__47E03294_5C6D_4094_A45D_467BC925EC7E__INCLUDED_)
#define AFX_EVT_H__47E03294_5C6D_4094_A45D_467BC925EC7E__INCLUDED_

#include "ObjDes.h" 


enum tipo_evt	{TIPO_EVT_SITE, TIPO_EVT_CIRCLE} ;

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CEvt : public CObject  
{
public:
	CEvt();
	virtual ~CEvt();

	CEvt(CObjDes &o);

	CObjDes *GetEvt();
	CPoint GetP1();
	CPoint GetP2();
	int GetY();


	bool IsSiteEvt();
	bool IsCircleEvt();

	
	// Seccao NICE CLASS!!! 
	CEvt(const CEvt& e) 
	{		
		evt = e.evt ;
		tipoevt = e.tipoevt ;
	}

	CEvt& operator= (const CEvt& e) 
	{
		evt = e.evt ;
		tipoevt = e.tipoevt ;
		return *this;
	}

	bool operator< (CEvt const &e) const
	{
		return ( evt->GetP1().y > e.evt->GetP1().y ) ;	
	}

	bool operator== (CEvt const &e) const
	{
		return ( evt->GetP1().x == e.evt->GetP1().x && evt->GetP1().y == e.evt->GetP1().y ) ;	
	}

	bool operator!= (CEvt const &e) const
	{
		return ( ! (evt->GetP1().x == e.evt->GetP1().x && evt->GetP1().y == e.evt->GetP1().y )) ;	
	}


	// fim NICE CLASS!!!!  

protected:

	CObjDes *evt ;     // Evento da lista: pode ser um EvtSite ou CEvtCircle
	tipo_evt tipoevt ;   // Tipo do evento da fila de eventos (Site ou Circle)
};

#endif // !defined(AFX_EVT_H__47E03294_5C6D_4094_A45D_467BC925EC7E__INCLUDED_)

// EOF
