// Quadrado.h: interface for the CQuadrado class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QUADRADO_H__1177E526_035E_41E2_A908_679AAC72DCE6__INCLUDED_)
#define AFX_QUADRADO_H__1177E526_035E_41E2_A908_679AAC72DCE6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ObjDes.h"

enum tipoquadrado {Q_QUADRADO, Q_RETANGULO} ;

class CQuadrado : public CObjDes  
{
public:
	CQuadrado();	
	virtual ~CQuadrado();
	void SetP1(CPoint p);
	void SetP2(CPoint p);
	void SetQuadrado();
	void SetRetangulo();
	void Draw(CDC *pDC);
	void UnDraw(CDC *pDC) ;
    virtual void Serialize(CArchive &ar);
    DECLARE_SERIAL(CQuadrado); 

protected:
	void CQuadrado::CalcRect(void);
	CRect rect; 
	tipoquadrado m_tipo ;
};

#endif // !defined(AFX_QUADRADO_H__1177E526_035E_41E2_A908_679AAC72DCE6__INCLUDED_)
