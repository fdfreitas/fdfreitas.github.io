// Facet.h: interface for the CFacet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FACET_H__4CFC21D4_E7B5_46CB_A624_7A66E01384FE__INCLUDED_)
#define AFX_FACET_H__4CFC21D4_E7B5_46CB_A624_7A66E01384FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "EvtSite.h"
#include "Plane.h"
#include "Vertex.h"

class CEdge;

class CFacet : public CEvtSite  
{
public:
	CFacet();
	CFacet(CPlane *plano, CEvtSite *s);
	virtual ~CFacet();

	CFacet *This();
	void SetSite(CEvtSite *s);
	CEvtSite *GetSite();

	// Seccao NICE CLASS!!! 
	CFacet(const CFacet& f)
	{		
		Plano = f.Plano;
		site = f.site;
	}

	CFacet& operator= (const CFacet& f) 
	{
		Plano = f.Plano;
		site = f.site;

		return *this;
	}

	bool operator< (CFacet const &f) const
	{
		return ( site  < f.site );
	}

	bool operator== (CFacet const &f) const
	{
		return ( site == f.site ) ;	
	}

	bool operator!= (CFacet const &f) const
	{
		return ( ! (site == f.site) ) ;	
	}
	// fim NICE CLASS!!!!  


public:

	CPlane *Plano;	 // Plano....
	CEvtSite *site ; // Site da face Voronoi

};



#endif // !defined(AFX_FACET_H__4CFC21D4_E7B5_46CB_A624_7A66E01384FE__INCLUDED_)

// EOF