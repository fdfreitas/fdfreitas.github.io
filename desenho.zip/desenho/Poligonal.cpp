// Poligonal.cpp: implementation of the CPoligonal class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Poligonal.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPoligonal::CPoligonal()
{
	m_arrayPontos.SetSize(0,10) ;
	n_desenhado = 0 ;
}

CPoligonal::~CPoligonal()
{
	m_arrayPontos.RemoveAll() ;
}

void CPoligonal::SetP1 (CPoint p)
{
	this->AdicionarPonto(p) ;
}

void CPoligonal::SetP2 (CPoint p)
{
	this->AdicionarPonto(p) ;
}


void CPoligonal::AdicionarPonto(CPoint ponto)
{
	m_arrayPontos.Add(ponto) ;
}

void CPoligonal::RetirarPonto()
{
	m_arrayPontos.RemoveAt(m_arrayPontos.GetUpperBound()) ;
}


CPoint CPoligonal::GetUltimoPonto()
{
		return m_arrayPontos.GetAt(m_arrayPontos.GetUpperBound()) ;
}

void CPoligonal::Draw(CDC *pDC)
{
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 

	int ncount = m_arrayPontos.GetSize(); 

	if( ncount > 1 ) { 
		CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 

		pDC->SetROP2(R2_COPYPEN); 

		pDC->MoveTo(m_arrayPontos[n_desenhado]); 

		for(int i = 0; i < ncount; i++) 
		{ 
			pDC->LineTo(m_arrayPontos[i]);
		}

		pDC->SelectObject(pOldPen); 
	}
}

void CPoligonal::UnDraw(CDC *pDC)
{

	CPen pen(PS_SOLID,m_nLargura,m_crCor); 

	int ncount = m_arrayPontos.GetSize(); 

	if( ncount > 1 ) { 
		CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 

		pDC->SetROP2(R2_NOT); 

		pDC->MoveTo(m_arrayPontos[ncount - 1]); 		

		int j = (ncount > 2? ncount - 2: 0) ;

		for(int i = ncount - 1; i >= j; i-- ) { 
		    pDC->LineTo(m_arrayPontos[i]); 
		}

		pDC->SelectObject(pOldPen); 
	}
}

 IMPLEMENT_SERIAL(CPoligonal,CObject,1);

 void CPoligonal::Serialize(CArchive &ar) 
 {

    CObject::Serialize(ar);

    if(ar.IsStoring() ) 
	{
		ar << (ULONG) m_crCor << m_nLargura;

       UINT size = m_arrayPontos.GetSize();

       ar << size;

       for(UINT i=0;i<size;i++) {
          CPoint p = m_arrayPontos[i];
          ar << p.x << p.y;
       }
    } 
	else 
	{ 
	   ULONG cor;
       ar >>  cor;
       m_crCor = (COLORREF) cor;
       ar >> m_nLargura;
       UINT size;
       ar >> size;
       for(UINT i=0;i<size;i++) {
          CPoint p;
          ar >> p.x >> p.y;
          m_arrayPontos.Add(p);
       }
    };
 }

// EOF

