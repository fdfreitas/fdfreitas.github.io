// Ponto.cpp: implementation of the CPonto class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Ponto.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPonto::CPonto()
{
	m_crCor = RGB (255, 0,0) ;

}

CPonto::CPonto(CPoint p)
{
	m_crCor = RGB (255, 0, 0) ;
	SetP1 (p) ;
}


CPonto::~CPonto()
{

}

void CPonto::SetP1(CPoint p)
{
	p1 = p ;
	CalcRect () ;
}


CPoint CPonto::GetP1()
{
	return p1 ;
}


void CPonto::CalcRect(void)
{
	/* O retangulo do ponto, diferente do circulo, eh centrado em P1 */

	// Vou usar R fixo em 2 pixels!!!!
	int r = 3 ;

	// calcula os vertices do retangulo da circunferencia
	rect.SetRect (p1.x - r, p1.y - r, p1.x + r, p1.y + r) ;  	
}


void CPonto::Draw(CDC *pDC)
{
	// desenha o ponto
	CPen pen(PS_SOLID,m_nLargura, m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 

	CBrush brush(m_crCor) ;
	CBrush *pOldBrush = (CBrush*)pDC->SelectObject(&brush);

	pDC->SetROP2(R2_NOTXORPEN); 

	pDC->Ellipse(rect) ;

	pDC->SelectObject(pOldPen); 
	pDC->SelectObject(pOldBrush); 
}


void CPonto::UnDraw(CDC *pDC)
{
	// desenha o ponto
	CPen pen(PS_SOLID,m_nLargura, m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 

	CBrush brush(m_crCor) ;
	CBrush *pOldBrush = (CBrush*)pDC->SelectObject(&brush);

	pDC->SetROP2(R2_NOTXORPEN); 

	pDC->Ellipse(rect) ;

	pDC->SelectObject(pOldPen); 
	pDC->SelectObject(pOldBrush); 
}



IMPLEMENT_SERIAL(CPonto,CObject,1);
void CPonto::Serialize(CArchive &ar) {

    CObject::Serialize(ar);
    if(ar.IsStoring() ) {

	   ar << (ULONG) m_crCor << m_nLargura;
       ar << (ULONG) p1.x << p1.y ;
    } 
	else 
	{ 
       ar >> (ULONG) m_crCor ;
	   ar >> m_nLargura;

	   CPoint p ;
	   ar >> p.x ;
	   ar >> p.y ;

	   SetP1 (p) ;
		
    } 
}


// EOF

