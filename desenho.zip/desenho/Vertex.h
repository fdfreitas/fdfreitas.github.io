// Vertex.h: interface for the CVertex class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VERTEX_H__A7CA6CC8_8A43_40BC_95A4_A391C57990E3__INCLUDED_)
#define AFX_VERTEX_H__A7CA6CC8_8A43_40BC_95A4_A391C57990E3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Ponto.h"
#include "Plane.h"
//#include "Edge.h"

enum vertextype {REAL, PROMOTED} ;


class CEdge;

class CVertex : public CPonto  
{
public:
	CVertex();
	CVertex(CPlane *plano, DPoint p, CEdge *e);
	CVertex(CPlane *plano, DPoint p, CEdge *e, vertextype t);
	virtual ~CVertex();
	CVertex *This();

	void SetIncEdge(CEdge *e) ;
	CEdge *GetIncEdge() ;
	vertextype GetType() ;
	void SetPoint(DPoint p);
	DPoint GetPoint();

	void Draw();
	void UnDraw();

	// Seccao NICE CLASS!!! 
	CVertex(const CVertex& v)
	{		
	    m_crCor = v.m_crCor;
		m_nLargura = v.m_nLargura; 
		p1 = v.p1; 
		p2 = v.p2;
		rect = v.rect ;
		Plano = v.Plano;
		type = v.type;
		inc_edge  = v.inc_edge;
		point = v.point;

	}

	CVertex& operator= (const CVertex& v) 
	{
	    m_crCor = v.m_crCor;
		m_nLargura = v.m_nLargura; 
		p1 = v.p1; 
		p2 = v.p2;
		rect = v.rect ;
		Plano = v.Plano;
		type = v.type;
		inc_edge  = v.inc_edge;
		point = v.point;

		return *this;
	}

	bool operator< (CVertex const &v) const
	{
		return ( p1.y < v.p1.y );
	}

	bool operator== (CVertex const &v) const
	{
		return ( p1.x == v.p1.x  && p1.y == v.p1.y ) ;	
	}

	bool operator!= (CVertex const &v) const
	{
		return ( ! (p1.x == v.p1.x  && p1.y == v.p1.y) ) ;	
	}
	// fim NICE CLASS!!!!  


private:

	CPlane *Plano;		// Plano do desenho
	CEdge	*inc_edge ; // Edge (aresta) incidente 
	vertextype type;    // tipo do vertice (REAL ou PROMOVIDO)
	DPoint  point ;     // Ponto do vertice

};

#endif // !defined(AFX_VERTEX_H__A7CA6CC8_8A43_40BC_95A4_A391C57990E3__INCLUDED_)

// EOF