// Circulo.h: interface for the CCirculo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CIRCULO_H__40CF44CB_AE88_44D3_8200_863628A1E97E__INCLUDED_)
#define AFX_CIRCULO_H__40CF44CB_AE88_44D3_8200_863628A1E97E__INCLUDED_


#include "Objdes.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum tipocirculo {C_CIRCULO, C_ELIPSE} ;

class CCirculo : public CObjDes
{
public:
	CCirculo();
	virtual ~CCirculo();
	void SetP1(CPoint p);
	void SetP2(CPoint p);
	CPoint GetC(void);
	UINT GetR(void);
	void Draw(CDC *pDC); 
	void UnDraw(CDC *pDC);
    virtual void Serialize(CArchive &ar);
    DECLARE_SERIAL(CCirculo); 

	void SetCirculo() ;
	void SetElipse() ;

 protected:
	void CCirculo::CalcRect(void);
	CPoint c; 
	UINT r; 
	CRect rect; 
	tipocirculo m_tipo ;
};

#endif // !defined(AFX_CIRCLE_H__BCEB93DD_5376_4BA2_B1E0_0E78F42C47D2__INCLUDED_)

// EOF