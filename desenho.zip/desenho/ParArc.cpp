// ParArc.cpp: implementation of the CParArc class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "ParArc.h"
#include <math.h>
#include <float.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CParArc::CParArc()
{

}

CParArc::~CParArc()
{

}

CParArc::CParArc(CEvtSite &s, CPlane *p)
{
	// site gerador do arco
	site = s ;

	// Plano do diagrama...
	Plano = p ;
	
	// MidPoint
	midpoint = BreakPoints.first.x + (BreakPoints.second.x - BreakPoints.first.x) / 2.0 ;

	// Y do arco
	Y_ = -1;
	Y = site.GetP1().y;	

	// BreakPoints...
	BreakPoints.first.x = BreakPoints.second.x = site.GetP1().x;
	BreakPoints.first.y	= BreakPoints.second.y = GetParVal(site.GetP1().x);	

	// Ponteiro para o evento de circulo associado...
	evtcirculo = NULL ;

	// Ponteiro para os edges associados...
	edge_l = NULL;
	edge_r = NULL;
}


CParArc *CParArc::This() 
{
	// QUANDO USO O ITERATOR DO SET PARARCS NAO CONSIGO DEREFERENCIA-LO PARA (CParArc *)!!!!!
	return (this) ;
}


void CParArc::SetY(int y) 
{
	Y  = y  ;

	// ajusta o circulo atraves de P2 
	CPoint p ;

	p.x = site.GetP1().x ;
	p.y = Y ;
}

int  CParArc::GetY() 
{
	return 	Y  ;
}


void CParArc::SetEvtCirculo(CEvtCircle *e) 
{
	evtcirculo = e ;
}

CEvtCircle *CParArc::GetEvtCirculo() 
{
	return evtcirculo ;
}


void CParArc::SetLeftEdge(CEdge *e) 
{
	edge_l = e ;
}

CEdge *CParArc::GetLeftEdge() 
{
	return edge_l ;
}

void CParArc::SetRightEdge(CEdge *e) 
{
	edge_r = e ;
}

CEdge *CParArc::GetRightEdge() 
{
	return edge_r ;
}



void CParArc::SetBreakPoints(pair<DPoint, DPoint> &p) 
{
	BreakPoints = p ;
	midpoint = BreakPoints.first.x + (BreakPoints.second.x - BreakPoints.first.x) / 2.0 ;
}

pair<DPoint, DPoint>& CParArc::GetBreakPoints() 
{
	return BreakPoints ;
}

double CParArc::GetMidPoint() 
{
	return midpoint ;
}


CPoint CParArc::GetP1() 
{
	return site.GetP1() ;
}

CEvtSite *CParArc::GetSite() 
{
	return &site ;
}

void CParArc::UnDrawResetMem() 
{
	// Apaga e reseta a memoria

	BreakPoints_.first.x = BreakPoints.first.x ;
	BreakPoints_.first.y = GetParVal(BreakPoints.first.x) ;

	BreakPoints_.second.x = BreakPoints.second.x ;
	BreakPoints_.second.y = GetParVal(BreakPoints.second.x) ;
}

void CParArc::UnDraw() 
{
	if ( Y_ != -1 )
	{
		int ytemp = GetY();
		SetY(Y_)  ; 

		// fazer configuravel!!!!
		m_crCor = RGB ( 0, 127, 64) ;
	
		CPen pen(PS_SOLID,m_nLargura,m_crCor); 
		CPen *pOldPen = (CPen *) Plano->pDC->SelectObject(&pen); 

		Plano->pDC->SetROP2(R2_NOTXORPEN); 

		_Draw(BreakPoints_) ; 

		Plano->pDC->SelectObject(pOldPen); 
		
		SetY(ytemp) ;
	}
}

void CParArc::Draw() 
{
	// fazer configuravel!!!!
	m_crCor = RGB ( 0, 127, 64) ;
	
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) Plano->pDC->SelectObject(&pen); 

	Plano->pDC->SetROP2(R2_NOTXORPEN); 

	_Draw(BreakPoints) ; 

	Plano->pDC->SelectObject(pOldPen); 

	 // Memoria dos parametros do desenha anterior para apagamento...

	Y_ = Y ;
	BreakPoints_ = BreakPoints;
}


void CParArc::_Draw(pair<DPoint, DPoint> bp)
{
	CPoint point;

	bool first_time = true ;

	int x_l, x_r ;
	double y ;
	
	x_l = (int) (bp.first.x + 0.5) ;

	if ( bp.first.x < (double) Plano->UL.x )
		x_l = Plano->UL.x ;
	else if ( bp.first.x > (double) Plano->LR.x )
		x_l = Plano->LR.x ;


	x_r = (int)(bp.second.x + 0.5) ;	

	if ( bp.second.x < (double) Plano->UL.x )
		x_r = Plano->UL.x ;
	else if ( bp.second.x > (double) Plano->LR.x )
		x_r = Plano->LR.x ;


	for ( point.x = x_l; point.x <= x_r ; point.x++ )
	{
		// uso o Y do BP por causa das singularidades e tambem para depurar o
		// o calculo dos BPs  
		// ** EH IMPORTANTE POR CAUSA DA INTERSECCAO DO ARCO DEGENERADO (FECHADO) **
		if ( (double) point.x == bp.first.x )

			y = bp.first.y ;	

		else if ( (double) point.x == bp.second.x)
		{
			y = bp.second.y ;
		}
		else		
			y = BETA( (double) point.x) ;
	
		//point.y = (int)(y + 0.5)  ;
		point.y = (int)(y)  ;

		if ( bp.first.x == bp.second.x )
		{
			Plano->pDC->MoveTo(point);
			point.y = GetY();
			Plano->pDC->LineTo(point);
		}

		if ( first_time )
		{
			Plano->pDC->MoveTo(point);
			first_time = false ;
		}
		else
			Plano->pDC->LineTo(point);	
	}
}


double CParArc::K () 
{
	double Py = (double) GetP1().y;
	double Ly = (double) GetY();

	if ( Py == Ly ) 
		return MAX_DOUBLE;

	return  1.0 / (2.0*(Py - Ly)) ;
}

double CParArc::W () 
{
	double Px = (double) GetP1().x;
	double Py = (double) GetP1().y;
	double Ly = (double) GetY();

	return  pow(Px,2.0)+ pow(Py,2.0) - pow(Ly,2.0) ;
}

double CParArc::BETA (double x) 
{
	double Px = (double) GetP1().x;
	double k = K();
	
	if ( k >= MAX_DOUBLE )
		return MIN_DOUBLE ;

	//if ( x <= MIN_DOUBLE || x >= MAX_DOUBLE )
	//	return MIN_DOUBLE;

	double ret = k * (pow(x,2.0) - 2.0*Px* x + W()) ;

	if ( ret >= MAX_DOUBLE )
		ret = MAX_DOUBLE;
	if ( ret <= MIN_DOUBLE )
		ret = MIN_DOUBLE;

	return  ret ;
}


double CParArc::GetParVal(double x) 
{
	double y ;
	y = BETA(x) ;
	return y ;
}

pair<double, double> CParArc::CalcRaizes() 
{

	return pair<double, double> (MIN_DOUBLE,MAX_DOUBLE) ;

	// Parms do arco
	double Px = (double) GetP1().x; 

	// singularidade
	if ( K() == MAX_DOUBLE )
		return pair<double, double> (Px,Px) ;

	// Parms da Formula Quadratica Ax^2 + Bx +c = 0: x= (-B +- sqrt(b^2-4AC))/2A

	double A = K() ;

	double B = -2.0 * Px * K() ;
	
	double C = W() * K() ;

	// Raizes...
	double x1 = (-1.0*B + sqrt(pow(B,2.0) - 4.0*A*C)) / (2.0*A) ;
	double x2 = (-1.0*B - sqrt(pow(B,2.0) - 4.0*A*C)) / (2.0*A) ;

	return pair<double, double> (x1,x2) ;
}

pair<double, double> CParArc::CalcIntersecao(CParArc *a) 
{
	// parms adicionais do arco esquerdo...
	double Px_e = (double) GetP1().x; 

	// parms adicionais do arco direito...
	double Px_d = (double) a->GetP1().x; 

	_fpreset();

	//--- singularidades---//
	if ( K() == MAX_DOUBLE && a->K() == MAX_DOUBLE ) // dupla!!!!
		return pair<double, double> (Px_e, Px_d) ; // nterseccao no infinito!!
	

	if ( K() == MAX_DOUBLE ) // singularidade no arco esquerdo
		return pair<double, double> (Px_e, Px_e) ;

	if ( a->K() == MAX_DOUBLE ) // singularidade no arco direito
		return pair<double, double> (Px_d, Px_d) ;


	// Parms da Formula Quadratica para a interseccao das parabolas
	double A = K() - a->K() ;

	double B = 2.0*Px_d* a->K() - 2.0*Px_e*K()  ;

	double C = W()*K() - a->W()*a->K() ;

	// Raizes...
	double x1 ;
	double x2 ;

	if ( A == 0.0 ) // vertices colineraes em X
	{
		x1 = -1.0*C / B ;
		x2 = x1 ;
	}
	else
	{
		x1 = (-1.0*B + sqrt(pow(B,2.0) - 4.0*A*C)) / (2.0*A) ;
		x2 = (-1.0*B - sqrt(pow(B,2.0) - 4.0*A*C)) / (2.0*A) ;
	}

	// Ordena os pontos de interseccao para facilitar....
	if ( x1 > x2 )
		swap(x1, x2) ;

	return pair<double, double> (x1,x2) ;
}

// EOF