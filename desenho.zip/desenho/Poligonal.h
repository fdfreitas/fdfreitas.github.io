// Poligonal.h: interface for the CPoligonal class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_POLIGONAL_H__BEE45AF8_1D18_409C_9274_A6511D985E30__INCLUDED_)
#define AFX_POLIGONAL_H__BEE45AF8_1D18_409C_9274_A6511D985E30__INCLUDED_

#include "objdes.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPoligonal : public CObjDes
 {
 public:
    CPoligonal();
    virtual ~CPoligonal();
	void SetP1(CPoint p);
	void SetP2(CPoint p);
	CPoint GetUltimoPonto();
    void Draw(CDC *pDC);
	void Draw2(CDC *pDC) ;
    void UnDraw(CDC *pDC);
    virtual void Serialize(CArchive &ar);
    DECLARE_SERIAL(CPoligonal); 
	void RetirarPonto();
 protected:
	void AdicionarPonto(CPoint ponto);
	 
	CArray<CPoint, CPoint &> m_arrayPontos;
	int n_desenhado ;
 };

#endif // !defined(AFX_POLIGONAL_H__BEE45AF8_1D18_409C_9274_A6511D985E30__INCLUDED_)
