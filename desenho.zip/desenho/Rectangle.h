// Rectangle.h: interface for the CRectangle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RECTANGLE_H__8C02EBB9_33D4_4901_98D0_8A24368C3E85__INCLUDED_)
#define AFX_RECTANGLE_H__8C02EBB9_33D4_4901_98D0_8A24368C3E85__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ObjDes.h"

class CQuadrado : public CObjDes  
{
public:
	CQuadrado();
	virtual ~CQuadrado();

};

#endif // !defined(AFX_RECTANGLE_H__8C02EBB9_33D4_4901_98D0_8A24368C3E85__INCLUDED_)
