// Vertex.cpp: implementation of the CVertex class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Vertex.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVertex::CVertex()
{
}

CVertex::CVertex(CPlane *plano, DPoint p, CEdge *e)
{
	SetarCor(RGB (127,50, 50)) ;
	Plano = plano ;
	SetIncEdge(e);
	point = p ;
	type = REAL ;
}


CVertex::CVertex(CPlane *plano, DPoint p, CEdge *e, vertextype t)
{
	SetarCor(RGB (127,50, 50)) ;
	Plano = plano ;
	SetIncEdge(e);
	point = p ;
	type = t ;
}

CVertex::~CVertex()
{

}

CVertex *CVertex::This()
{
	return this;
}

void CVertex::SetIncEdge(CEdge *e)
{
	inc_edge = e ;
}

CEdge *CVertex::GetIncEdge()
{
	return inc_edge ;
}

void CVertex::SetPoint(DPoint p)
{
	point = p ;
}

DPoint CVertex::GetPoint()
{
	return point ;
}



vertextype CVertex::GetType()
{
	return type ;
}


void CVertex::Draw()
{

	CPonto p ;
	CPoint ponto;

	// desenha o ponto do vertex
	ponto.x = (int)(point.x + 0.5) ; 
	ponto.y = (int)(point.y + 0.5) ;

	// desenha a circunferencia
	CPen pen(PS_SOLID,1, RGB(50,50,200)); 
	CPen *pOldPen = (CPen *) Plano->pDC->SelectObject(&pen); 

	CBrush brush(RGB(50,50,200)) ;
	CBrush *pOldBrush = (CBrush*) Plano->pDC->SelectObject(&brush);

	Plano->pDC->SetROP2(R2_COPYPEN); 
	//pDC->SetROP2(R2_NOTXORPEN); 

	CRect rect;
	int r = 3 ;
	rect.SetRect (ponto.x - r, ponto.y - r, ponto.x + r, ponto.y + r) ;  	
	Plano->pDC->Ellipse(rect) ;

	Plano->pDC->SelectObject(pOldPen); 
	Plano->pDC->SelectObject(pOldBrush); 

}

void CVertex::UnDraw()
{
/*
	CPonto p ;
	CPoint point;

	// desenha o ponto do vertice
	point.x = (int)(ponto.x + 0.5) ; 
	point.y = (int)(ponto.y + 0.5) ;
	p.SetarCor(m_crCor);
	p.SetP1(point) ;
	p.Draw(Plano->pDC); 
*/
}

// EOF