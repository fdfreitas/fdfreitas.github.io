// Ferramenta.h: interface for the CFerramenta class.
//
//////////////////////////////////////////////////////////////////////

#include "ObjDes.h"
#include "DesenhoDoc.h"

#if !defined(AFX_FERRAMENTA_H__C77EE99F_3620_4B3D_A554_E5413FF97039__INCLUDED_)
#define AFX_FERRAMENTA_H__C77EE99F_3620_4B3D_A554_E5413FF97039__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFerramenta : public CObject  
{
public:
	CFerramenta();
	virtual ~CFerramenta();
	SetTipoDesenho(tipodesenho t) ;
	void OnLButtonDown(CDesenhoDoc* pDoc, CDC *pDC, UINT nFlags, CPoint point);
	void OnMouseMove(CDesenhoDoc* pDoc, CDC *pDC, UINT nFlags, CPoint point);
	void OnLButtonUp(CDesenhoDoc* pDoc, CDC *pDC, UINT nFlags, CPoint point);
	void OnLButtonDblClk (CDesenhoDoc* pDoc, CDC *pDC, UINT nFlags, CPoint point);
	void OnKeyDown(CDesenhoDoc* pDoc, CDC *pDC, UINT nChar, UINT nRepCnt, UINT nFlags);
protected:
	CObjDes *m_pObjDesTemp;
	BOOL m_bTracando;
	tipodesenho	m_tipo ;
};

#ifndef _DEBUG  // debug version in DesenhoView.cpp
inline CDesenhoDoc* CFerramenta::GetDocument()
   { return (CDesenhoDoc*)m_pDocument; }
#endif

#endif // !defined(AFX_FERRAMENTA_H__C77EE99F_3620_4B3D_A554_E5413FF97039__INCLUDED_)

// EOF
