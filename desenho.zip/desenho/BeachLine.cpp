
// BeachLine.cpp: implementation of the CBeachLine class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "BeachLine.h"
#include <math.h>
#include <time.h>
#include <algorithm>



#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBeachLine::CBeachLine()
{

}

CBeachLine::CBeachLine(CPlane *p)
{
	Plano = p ;
}


CBeachLine::~CBeachLine()
{

}

void CBeachLine::Clear ()
{
	parcs.clear();
}

void CBeachLine::SetPlane(CPlane *plano)
{
	Plano = plano ;
}

void CBeachLine::Setup(CEventQueue *q,list<CEdge> *e,list<CVertex> *v,list<CFacet> *f)
{
	equeue = q ;
	edgelist = e ;
	vertexlist = v;
	facetlist = f;
}

void CBeachLine::SetY(int y)
{
	Y = y ;
}


int CBeachLine::GetY()
{
	return Y ;
}

void CBeachLine::SetShowCircle(bool b)
{
	show_circle = b ;
}

void CBeachLine::SetShowBeach(bool b)
{
	show_beach = b ;
}


CParArc *CBeachLine::FindArcAbove(CParArc *a)
{
	// testa o set
	if ( parcs.empty() ) 
		return NULL ;

	pair<DPoint, DPoint> bp ;
	CParArc *b ;
	multiset<CParArc>::iterator found ;
	double x ;

	x = a->GetMidPoint();
	
	//found = parcs.upper_bound(*a) ;
	// retorna o primeiro elemento que eh maior que o meu (a)
	found = parcs.lower_bound(*a) ;

	// Testes do found....

	// nao ha elemento maior ou igual que o meu! Testo o anterior
	if ( found == parcs.end() )
		found--;

	do {
		b  = found->This() ;
		bp = found->GetBreakPoints();

		// Ok? X dentro do range do arco?
		if ( x >= bp.first.x && x <= bp.second.x )
			return b;

		if ( found == parcs.begin() ) 
			break;
		found--;

	} while ( 1 ) ;

	// So...Quit!!!
	return NULL ;
}

multiset<CParArc>::iterator CBeachLine::FindArcIterator(CParArc *a)
{
	multiset<CParArc>::iterator found ;
	CParArc *f ;

	found = parcs.lower_bound(*a);

	while ( found != parcs.end() )
	{
		f = found->This() ;
		if ( f == a )
			break;

		found++ ;
	}

	return found ;
}

multiset<CParArc>::iterator CBeachLine::FindEvtCircleArcIterator(CEvtCircle *e, CParArc *a)
{
	multiset<CParArc>::iterator found ;
	multiset<CParArc>::iterator found_ ;
	CParArc *f ;

	// *** ATENCAO: Melhorar a eficiencia desta busca *** //
	found_ = parcs.lower_bound(*a);
	
	found = found_ ;
	while ( found != parcs.end() )
	{
		f = found->This() ;
		if ( f == a && f->GetEvtCirculo() == e )
			return found;

		found++ ;
	}

	found = found_ ;
	while ( found != parcs.end() )
	{
		f = found->This() ;
		if ( f == a && f->GetEvtCirculo() == e )
			return found;

		found-- ;
	}

	return found ;
}


//////////////////////////////////////////////////
// @@ AddSite
// insere um arco tratando os edges
//////////////////////////////////////////////////

CParArc *CBeachLine::Add(CEvtSite *e)
{
	// Adiciona o arco, inicializando seu site de referencia	
	multiset<CParArc>::iterator i_ret ;
	multiset<CParArc>::iterator i_ant ;
	multiset<CParArc>::iterator i_post ;
	pair<DPoint,DPoint> bp ;		
	CEdge *edge, *edge_ ;
	list<CEdge>::iterator i_e_l ;
	list<CEdge>::iterator i_e_r ;

	// cria e inicializa o novo arco
	CParArc *a = new CParArc(*e, Plano) ;
	bp.first.x = bp.second.x = (double) e->GetP1().x ;		
	bp.first.y = bp.second.y = a->GetParVal(bp.first.x);
	a->SetBreakPoints(bp);

	//--- Procura o arco acima do novo site Pj que tocou a SweepLine
	// O x eh a posiccao do novo site 
	double x = a->GetMidPoint()	; 

	CParArc *f = FindArcAbove (a) ;
		
	//---Havia arco acima do novo arco????---//
	if ( f == NULL ) // Nao ha arco acima do novo site, ou o set esta vazio !!!
	{
		//--- insere o arco e retorna o iterator para o arco inserido ---//
		i_ret = parcs.insert(*a);  
		delete a ;

		// -- Insercao dos Half-Edges pertinentes ----------------------------------------------------//
		// se existe(m) outro(s), tem que incluir os half-edges para este caso (sem intersecao)
		// a origem ao inves de ser no centro do arco eh no midpoint entre estes.
		// Ainda, o arco esquerdo so tem o half-edge direitop e o direito o esquerdo.
		//
		//     ESQ  o<------|------>o  DIR
		//
		// OBS 1: os This()GetBreakPoints().second.x sao apenas didatiscos, pois *todos* os arcos
		// estao fechados e entao BP.first.x == BP.second.x = Px
		// OBS 2: os BPs extremos dos arcos (first do arco maisa esquerda e second do arco mais a direita
		// *nao* recebem half-edges!

		if ( parcs.size() > 1 )
		{
			// A mediana esta entre o *novo arco* e o arco a direita
			// Orig eh fixada na mediana e o Dest eh mantido pelo arco a direita!
			// tem arco a direita?
			
			//  situar o novo arco em relaccao ao existentes
			double x, x_ant, x_post ;
			DPoint p_ant, p_post;
			
			CParArc *ant = NULL, *novo = i_ret->This(), *post = NULL;

			i_post = i_ret; 
			i_post++;	
			if ( i_post != parcs.end() )
				post = i_post->This();
			i_ant = i_ret;
			i_ant--;
			if ( i_ant != parcs.end() )
				ant = i_ant->This();

			// calcula a mediana com o arco a esquerda
			if ( ant != NULL )
			{
				x     = novo->GetBreakPoints().first.x;
				x_ant = ant->GetBreakPoints().second.x;
				p_ant.x = x_ant  + (x - x_ant) / 2.0 ;
				//p_ant.y = novo->GetParVal(p_ant.x) ; // Vai retornar - oo (MIN_DOUBLE)
				p_ant.y = MIN_DOUBLE;
			}
			// calcula a mediana com o arco a direita
			if ( post != NULL )
			{
				x      = novo->GetBreakPoints().second.x;
				x_post = post->GetBreakPoints().first.x;
				p_post.x = x  + (x_post - x) / 2.0 ;
				//p_post.y = novo->GetParVal(p_post.x) ;	// Vai retornar - oo (MIN_DOUBLE)
				p_post.y = MIN_DOUBLE;
			}

			// Novo arco esta a direita do ultimo arco! (nao tem arco a direita....)
			if ( post == NULL )
			{
				// a Orig do edge fixa fixa em (m, y(m) ) e o Dest fica atrelado sob responsabilidade
				// do *novo* arco, que esta a direita (atravez do seu BP_e)
				edge = AddEdge(p_ant, novo->GetBreakPoints().first, novo->GetSite(), ant->GetSite());
				novo->SetRightEdge(edge);

				// cria o vertice promovido de origem...
				//v = AddVertex(p_ant, edge, PROMOTED);
				//edge->SetOrig(v) ;
			}
			else 
			{	
				// tem arco a esquerda...Novo arco esta no meio deles! Faz o Swap dos Edges!
				if ( ant != NULL )
				{
					// Ajusta o edge existente no arco a direita para o swap, mudando sua origem
					// para entre o *novo arco* e o a esquerda!
					edge_ = post->GetRightEdge();
					edge_->SetOrig(p_ant);
					edge_->SetDest(novo->GetBreakPoints().first);
					novo->SetRightEdge(edge_);
				}

				// a Orig do edge fixa fixa em (m, y(m) ) e o Dest fica sob responsabilidade
				// do arco a direita do *novo* arco, (atraves do seu BP_e)
				edge = AddEdge(p_post, post->GetBreakPoints().first, post->GetSite(), 
							   novo->GetSite());
				post->SetRightEdge(edge);

				// cria o vertice promovido de origem...
				//v = AddVertex(p_post, edge, PROMOTED);
				//edge->SetOrig(v) ;
			}

		}
	}
	else
	{
		//--- Verifica o *FALSO ALARME*-------------------------------------------------//
		CEvtCircle *c = f->GetEvtCirculo();
		if ( c != NULL )
		{
			if ( show_circle ) c->UnDraw();
			equeue->RemoveForEvtCircle(c) ;			
		}

		/* Ha o arco f acima do novo site!
		   Na estrutura de arvore do Fortune:
			Troca a folha do arco por uma sub arvore com 3 folhas e 2 nos internos:
				- a folha do meio tem o novo site Pi.
				- as duas outras folhas teem o site Pj do arco encontrado. 
				- os nos internos de breakpoint <Pj, Pi> e <Pi, Pj>
				- rebalabcear se for necessario
				- ?? calculo dos breakpoints??
			Na minha estrutura de multiset<>:				
				- Insiro dois arcos Pj e Pi apos o arco de Pi
				- Reacalculo os breakpoints
		*/

		// ajuste no arco acima do site encontrado!
		// mas, antes, copio o arco para a inserccao apos o novo arco - 
		// 0 ARCO ORIGINAL SERA SEGMENTADO PELO NOVO ARCO	
		// e ajusta os breakpoints

		// Preciso apagar e resetar a memoria dos arcos, pois criarei novos arcos....

		CParArc *n = new CParArc(*f) ;

		//--- ajuste no arco original -> Primeiro segmento do arco original
		bp = f->GetBreakPoints();
		bp.second.x = x ;
		bp.second.y = f->GetParVal(x) ;	
		f->SetBreakPoints(bp);			
		f->UnDrawResetMem(); // apaga a memoria de desenho

		//--- ajuste do segundo novo arco -> Segundo segmento do arco original	
		bp = n->GetBreakPoints(); 
		bp.first.x = x ;
		bp.first.y = f->GetParVal(x); 
		n->SetBreakPoints(bp);
		n->UnDrawResetMem(); // apaga a memoria de desenho

		//--- ajuste no novo arco do site encontrado ->  o arco esta fechado (degenerado)
		// --- e intersecta outro arco (valor do y)
		bp = a->GetBreakPoints();
		bp.first.x = bp.second.x = x ;		
		bp.first.y = bp.second.y = f->GetParVal(x); // Y da Interseccao!!!			
		a->SetBreakPoints(bp);

		//--Criacccao dos edges....
		// o arco *novo* eh o responsavel pela Orig do edge (atravez do seu BP_e)
		// e o arco a direita eh responsavel pelo Dest do edge (atravez do seu BP_e)

		edge = AddEdge(a->GetBreakPoints().first, n->GetBreakPoints().first, 
					   f->GetSite(), a->GetSite() );
		
		a->SetLeftEdge(edge);
		a->SetRightEdge(NULL);

		n->SetLeftEdge(NULL);		
		n->SetRightEdge(edge);

		//--- insere os novos arcos e retorna o iterador para o *novo* arco completo inserido---//
		i_ret = parcs.insert(*a);  
		delete a ;
		parcs.insert(*n);
		delete n ;
	}

	return i_ret->This() ;
}


void CBeachLine::CalcBreakPoints()
{

	if ( parcs.size() < 1 ) return ;

	CParArc *arco_e, *arco_d;

	multiset<CParArc>::iterator first = parcs.begin() ;
	multiset<CParArc>::iterator last  = parcs.end() ;

	multiset<CParArc>::iterator first_arco  = parcs.begin() ;
	multiset<CParArc>::iterator last_arco   = parcs.end() ;
	last_arco-- ;

	multiset<CParArc>::iterator it_e ;		// Iterator do Arco esquerdo
	multiset<CParArc>::iterator it_d ;		// Iterator Arcos direito
	multiset<CParArc>::iterator it_n ;		// Iterator do arco posterior ao direito 

	pair<DPoint,DPoint> bp_e ;	// BreakPoints do arco esquerdo
	pair<DPoint,DPoint> bp_d ;	// BreakPoints do arco direito

	pair<DPoint,DPoint> bp ;	// BreakPoints do arco 

	pair<double, double> raizes_arco_e, raizes_arco_d, intersecao ;	

	CEdge *edge ;

	// condiccao dex parada do sweep //
	all_bp_out_of_plane = true ;

	while ( first != last ) 
	{
		//--- Arco esquerdo
		it_e = first ;
		arco_e = it_e->This() ;
		
		// Raizes do arco esquerdo ( interseccao com o bound Y Plano )
		arco_e->SetY(Y) ;

		// se for o 1o arco da BeachLine, senao, o bp_e.first ja foi ajustado 
		// no bp_d.first da iteraccao anterior!
		if ( it_e == parcs.begin() ) 
		{
			// Trata a singularidade do arco degenerado (fechado)
			if ( arco_e->K() == MAX_DOUBLE )
				bp_e.first.x = (double) arco_e->GetP1().x ; 
			else
				bp_e.first.x   = MIN_DOUBLE ; 
		}
		else
			bp_e.first.x = bp_d.first.x ; 

		//--- Arco direito ---
		it_d = ++first;
		bool tem_arco_direito = ( it_d != last) ;


		if ( tem_arco_direito )
		{
			arco_d = it_d->This() ;

			// Raizes do arco direito ( interseccao com o bound Y Plano )
			arco_d->SetY(Y) ;

			//---Calcula os BreakPoints DIREITO do ARCO ESQUERDO e o ESQUERDO do ARCO DIREITO---//			
			// dummy BreakPoint, pois sera recalculado na proxima iteraccao ...

			if ( arco_d->K() == MAX_DOUBLE )
				bp_d.second.x = (double) arco_d->GetP1().x ; 
			else
				bp_d.second.x   = MAX_DOUBLE ; 

			// Interseccao entre os arcos...
			intersecao = arco_e->CalcIntersecao(arco_d) ;
 
			if ( arco_e->K() == MAX_DOUBLE && arco_d->K() == MAX_DOUBLE ) // intersec. no inf.
			{
				bp_e.second.x = intersecao.first;	
				bp_d.first.x  = intersecao.second ; 
			}
			else
			{
				// Seleciona o ponto da ntersecao correto ( menor ponto maior que o bp_e.first...
				// OBS: podem ocorrer erros aqui devido a opequenas diferenccas do calculo
				// de interseccoes no mesmo ponto a partir de 3 parabolas: P1, P2 e P3 se 
				// intersectam em pto, porem ha direfencca no calculo de pto com P1 e P2 e 
				// (apos P2 desaparecer) P1 e P3 

				if ( intersecao.first > bp_e.first.x + DBL_MIN_ERROR)
	
					bp_e.second.x = intersecao.first ;

				else if ( intersecao.second > bp_e.first.x + DBL_MIN_ERROR)

					bp_e.second.x = intersecao.second;

				bp_d.first.x  = bp_e.second.x ; 
			}

			// ARCO DIREITO: calcula os y...;

			if ( arco_d->K() == MAX_DOUBLE )
				bp_d.first.y  = bp_d.second.y = arco_e->GetParVal(intersecao.first) ; 
			else
				bp_d.first.y  = bp_d.second.y = arco_d->GetParVal(bp_d.first.x) ; 

			// ARCO DIREITO: Ajusta os BreakPoints...
			arco_d->SetBreakPoints(bp_d);		
		}
		else
		{
			if ( arco_e->K() == MAX_DOUBLE )
				bp_e.second.x = (double) arco_e->GetP1().x ; 
			else
				bp_e.second.x = MAX_DOUBLE ; 
		}

		// ARCO ESQUERDO: calcula os y...
		// caso do arco fechado: Se o esquerdo atual for o antigo direito, fica intacto, 
		// (pois ja os seus BPs ja foram calculados corretamente quando ele era o arco
		// direito) se for um arco inicial (fechado) sem interseccao ou outro caso, calcula 
		// normalmente , onde o y retornado por GetParVal eh 0 (K == INF)
		if ( tem_arco_direito && intersecao.first == intersecao.second && arco_e->K() == MAX_DOUBLE )
		{
			bp_e.first.x =  bp_e.second.x = intersecao.first ;	
			bp_e.first.y =  bp_e.second.y = arco_d->GetParVal(intersecao.first) ;	
		}
		else
		{
			bp_e.first.y  =  arco_e->GetParVal(bp_e.first.x) ;			
			bp_e.second.y =  arco_e->GetParVal(bp_e.second.x) ;			
		}
		arco_e->SetBreakPoints(bp_e);	

		// Ajusta os edges de Voronoi do arco
		if ( tem_arco_direito )
		{
			edge = arco_e->GetLeftEdge() ;
			if ( edge != NULL )
				edge->SetOrig(bp_e.first);

			edge = arco_d->GetRightEdge() ;
			if ( edge != NULL )
				edge->SetDest(bp_d.first); // ou bp_e.second
		}

		if ( BPInPlane(bp_e.first) )
			all_bp_out_of_plane = false ;

	}	
}


//////////////////////////////////////////////////
// @@ BPInPlane
// Verifica se o break point esta no plano
//////////////////////////////////////////////////
bool CBeachLine::BPInPlane(DPoint p)
{
	if ( p.x >= Plano->UL.x && p.y >= Plano->UL.y &&
		 p.x <= Plano->LR.x && p.y <= Plano->LR.y )

		 return true ;

	return false ;
}

//////////////////////////////////////////////////
// @@ CanStopSweep
// Verifica se os BPs e stao fora do plano o swwep podex ser parado
//////////////////////////////////////////////////
bool CBeachLine::CanStopSweep()
{
	if ( all_bp_out_of_plane && Y >= Plano->LR.y )
		 return true ;
	return false ;
}


//////////////////////////////////////////////////
// @@ CalcCircleEvents
// Calcula o evento de circulo
//////////////////////////////////////////////////

CEvtCircle *CBeachLine::CalcCircleEvents (multiset<CParArc>::iterator it_arco_inicial)
{
/*
		--- Relaccoes Geometricas da Circunferencia ---

			Equaccao geral da Circunferencia:
			
				x^2 + y^2 + Dx + Ey + F = 0

			Centro da Circunferencia (x0, y0) :

				x0 = D / -2
				y0 = E / -2

			Raio da circunferencia (R)
			
				R = (x0^2 + y0^2 - F)^-1/2


		--- O Solver resolve A * X = C ---
		
		Assim, como  
			
			  x^2 + y^2 + Dx + Ey + F = 0

		e sendo para cada ponto x, y:
		
			K = x^2 + y^2 

		Temos para cada ponto x,y:

			Dx + Ey + F = -K


		O sistema entao fica:

		| x1   y1  1 |   | D |   | -K1 |
		|            |   |   |   |     |
		| x2   y2  1 | * | E | = | -K2 |
		|            |   |   |   |     |
		| x3  y3   1 |   | F |   | -K3 |
		

*/

	CEvtCircle *ret = NULL ;

	// Uma vez que este metodo eh chamado apos a inserccao de um novo arco,	
	// nao ha evento de circulo com menos que 4 sites pois 3 sites 
	// implica no novo arco inserido e nas duas partes do antigo arco ao lado.

	if ( parcs.size() < 3 ) return NULL ; 

	// Teste de orientacccao tem que ser positivo!
	double orientation = OrientationTest(it_arco_inicial);

	if ( !(orientation > 0.0) ) 
		return NULL;

	// CUIDADO!!! As rotinas do Solver funcionam com indice comeccando em 1!!!!!
	Matrix A = CreateMatrix(3+1, 3+1);
	Vector X = CreateVector(3+1);
	Vector C = CreateVector(3+1);

	CParArc *a, *disap_arc ;

	multiset<CParArc>::iterator first = parcs.begin() ;
	multiset<CParArc>::iterator last  = parcs.end() ;

	// verifica se ha Evento de Circulo na tripla de arcos iniciadas em it_arco_inicial,
	// assim:
	//		arco(it_arco_inicial) - arco2 - arco3 
	// 
	// onde, arco-2 sera, no caso da comnvergencia dos breakpoints (evento de circulo)
	// o arco selecionado para desaparecer no futuro 

	// OBS: *A funccao chamadora eh encarregada de verificar a existencia dos 3 arcos*

	// monta as matrizes para o solver 

	bool arco_fechado = false ;
	double vx[3] ;

	for ( int i = 1; i <= 3 && it_arco_inicial != last; i++ )
	{
		a = it_arco_inicial->This() ;

		if ( a->K() == MAX_DOUBLE )
			arco_fechado = true ;

		// guarda o Arco central da tripla, pois se hou\ver um Evento de Circulo aqui,
		// este sera o arco associado ao evento de circulo que ira desaparecer na sua 
		// ocorrencia.
		if ( i == 2 ) 
			disap_arc = a->This();	

		double x = a->GetP1().x ;
		double y = a->GetP1().y ;

		double K = pow(x,2.0) + pow(y,2.0) ;
		
		A[i][1] = x ;
		vx[i-1] = x ;

		A[i][2] = y ;
		A[i][3] = 1.0;
		
		C[i] = -1.0 * K ;

		// proximo da tripla...	
		it_arco_inicial++ ;
	}

	// Ha 3 arcos?
	if ( i != 4 )
		return NULL ;

	Solve(A, 3, C, X) ;

	double D = X[1] ;
	double E = X[2] ;
	double F = X[3] ;

	double x0 = D / -2.0 ;
	double y0 = E / -2.0 ;
	double R = sqrt (pow(x0,2.0) + pow(y0,2.0) - F);
	
	// verifica se realmente achou um circulo valido (por causa de erros de arredondamento)	 
	if ( R > 0.0 && R < MAX_DOUBLE /*&& (! (disap_arc->K() == MAX_DOUBLE && (int)(y0 + R) == Y) )*/ )
	{
		// inclui o evento de circulo na fila de eventos...
		CEvtCircle *ecircle = new CEvtCircle (Plano, x0, y0, R) ;

		// Ajusta os apontadores de do Evento de Circulo para o Arco e 
		// do arco para o Evento de Cirtculo, que serao uteis no no 
		// tratamento dos eventos de circulo...
		ecircle->SetArco(disap_arc) ;
		disap_arc->SetEvtCirculo(ecircle) ;

		// previne erros dearredondamento....
		ret = ecircle ;
	}

	// libera as matrizes....
	DestroyMatrix (3+1, A);
	DestroyVector (X);
	DestroyVector (C);

	return ret ;
}


Matrix CBeachLine::CreateMatrix(int l, int r)
{
    int i;
    Matrix a;

    a = (double **) calloc(l, sizeof(double *));
    for (i = 0; i < l; i++)
	a[i] = (double *) calloc(r, sizeof(double));

    return (a);
}


void CBeachLine::DestroyMatrix(int l, Matrix a)
{
    int i;
    for (i = 0; i < l; i++)
		free (a[i]) ;
}


Vector CBeachLine::CreateVector(int r)
{
    Vector a;

    a = (double *) calloc(r, sizeof(double));

    return (a);
}

void CBeachLine::DestroyVector(Vector a)
{
   free (a);
}


void CBeachLine::Solve(Matrix gk, int nnodes, Vector gf, Vector x)
{
	int m1, i, j, k, j1, ib;
	double tiny, fac;

	m1 = nnodes - 1;
	tiny = 1e-30;

	/* tri */
	for (i = 1; i <= m1; ++i) {
		/*
		if (gk[i][i] < tiny) {
			fprintf(stderr, "Reduction failed due to small pivot\n");
			exit(-1);
		}
		*/
		j1 = i + 1;

		for (j = j1; j <= nnodes; ++j) {
			if (gk[j][i] != 0) {
				fac = gk[j][i] / gk[i][i];
				
				for (k = j1; k <= nnodes; ++k) {
				    gk[j][k] = gk[j][k] - gk[i][k] * fac;
				}
				//  gf[j] = gf[j] - gf[i] * gk[j][i] / gk[i][i];
			}
		}
	}


	/* rhsub */
	for (i = 1; i <= m1; ++i) {
		j1 = i + 1;
		for (j = j1; j <= nnodes; ++j) {
			gf[j] = gf[j] - gf[i] * gk[j][i] / gk[i][i];
		}
	}
	x[nnodes] = gf[nnodes] / gk[nnodes][nnodes];

	for (i = 1; i <= m1; ++i) {
		ib = nnodes - i;
		j1 = ib + 1;
		for (j = j1; j <= nnodes; ++j) {
			gf[ib] = gf[ib] - gk[ib][j] * x[j];
			x[ib] = gf[ib] / gk[ib][ib];
		}
	}
}



//////////////////////////////////////////////////
// @@ OrientatioTest
// 
//////////////////////////////////////////////////

double CBeachLine::OrientationTest(multiset<CParArc>::iterator it_arco_inicial)
{
/*
	| ax  ay  1 |	 |				|	/   < 0  
	|			|	 | ax-cx  ay-cy |   |
	| bx  by  1	| == |				|  -|   0 --> pontos estao num k-flat comum para k < 2
	|			|	 | bx-cx  by-cy |   |
	| cx  cy  1 |	 |				|	\   > 0 
*/

	double ax = (double) it_arco_inicial->This()->GetP1().x ;
	double ay = (double) it_arco_inicial->This()->GetP1().y ;

	it_arco_inicial++;

	double bx = (double) it_arco_inicial->This()->GetP1().x ;
	double by = (double) it_arco_inicial->This()->GetP1().y ;

	it_arco_inicial++;

	double cx = (double) it_arco_inicial->This()->GetP1().x ;
	double cy = (double) it_arco_inicial->This()->GetP1().y ;

	double A = (ax - cx) * (by - cy);
	double B = (bx - cx) * (ay - cy);

	return A - B ;
}


void CBeachLine::AddEvtCircle(CEvtCircle *c)
{
	// cria o evento para inclusao na fila
	CEvt *evt    = new CEvt (*c) ; 			
	equeue->Push(*evt); 							
	// desenha o Circulo...

	if ( show_circle )
		c->Draw() ;

	// ATENCCAO: *NAO PODE deletar ecircle* pois evt gurada um apontador para ele.
	delete evt ;
}

//////////////////////////////////////////////////
// @@ HandleSiteEvent
// Processa o evento de site
//////////////////////////////////////////////////

CParArc *CBeachLine::HandleSiteEvent (CEvtSite *e)
{

	CParArc *novo_arco ;	
	CEvtCircle *c ;

	//=== 1- adiciona o evento de site no BeachLine vazio, ou sem 
	//    arco acima do evento de site.
	//=== 2- adiciona o evento de site com um arco existente acima
	//    deste.
	//=== 3- Verifica falso alarme de Evento de Circulo associado ao 
	//    arco acima do novo evento de site.
	//=== 4 - Inserccao de edges de Voronoi
	
	//--- adiciona o Evento de Site ---//
	novo_arco = Add(e); 

	//--- retira o Evento de Site adicionado da Fila de Eventos ---//	
	// tem que trazer o proximo agora pois no CalcCiecleEvents pode 
	// surgir novos eventos com  este Y...
	equeue->Pop() ; 

	// 5 - Verificar a ocorrencia de eventos de Circulo
	//     no entorno do novo arco inserido.		

	// Calcula os eventos de circulo e os *insere* na Fila de Eventos se necessario ---//
	// Serao verificados sa seguintes triplas de arcos:
	//		novo_arco-arco1-arco2 e arco1-arco-novo_arco

	multiset<CParArc>::iterator first = parcs.begin() ;
	multiset<CParArc>::iterator last  = parcs.end() ;
	multiset<CParArc>::iterator found ;

	found = FindArcIterator(novo_arco) ;
	if ( found == parcs.end() ) 
		return NULL; // situaccao de erro! Pois, p acabou de ser incluido em Add()

	//--- novo arco na esquerda: tripla novo_arco-arco1-arco2 ---//
	c = CalcCircleEvents (found) ;
	if ( c != NULL )
		AddEvtCircle(c);

	//--- arco p na direita ( 2 arcos antes de p )  ---//
	found-- ;
	if ( found == parcs.end() ) 
		return novo_arco; // p eh o primeiro arco da BeachLine....nao ha 3 arcos, desiste!
	found-- ;
	if ( found == parcs.end() ) 
		return novo_arco; // p eh o segundo arco da BeachLine...nao ha 3 arcos, desiste!
	
	//--- novo arco na direita: tripla arco1-arco2-novo_arco ---//
	c = CalcCircleEvents (found) ;
	if ( c != NULL )
		AddEvtCircle(c);

	return novo_arco ;
}


//////////////////////////////////////////////////
// @@ HandleCircleEvent
// Processa o evento de circulo
//////////////////////////////////////////////////

void CBeachLine::HandleCircleEvent (CEvtCircle *e)
{

	CParArc *a , *p, *f, *disap_arc ;
	list<CVertex>::iterator i_v ;
	list<CEdge>::iterator i_e_l ;
	list<CEdge>::iterator i_e_r ;
	CEvtCircle *c ;

	a = NULL;
	p = NULL;
	
	bool tem_ant = true ;
	bool tem_post = true ;

	// 1-Remove o arco asociado ao Evento de Circulo da BeachLine (Parabolic Front)
	// e todos os eventos de Circulo que envolvem este arco.
	multiset<CParArc>::iterator first = parcs.begin();
	multiset<CParArc>::iterator last = parcs.end();
	multiset<CParArc>::iterator found ;
	multiset<CParArc>::iterator ant ;
	multiset<CParArc>::iterator post ;
	
	// Busca o iterador para o arco associado ao evento de circulo
	// OBS: note que eh necessario passaro EvtCircle para o caso de  
	// um arco participar de varios eventos de circulo.

	disap_arc = e->GetArco() ;

	found = FindEvtCircleArcIterator(e, disap_arc) ;

	if ( found == parcs.end() ) 
	{
		// FALSO EVENTO!! Eh um *ERRO* pois os falsos eventos ja deveriam ter sido removidos
		equeue->Pop() ;
		return ;
	}
	ant  = found ;
	post = found ;

	// Arco que sera retirado....
	f = found->This() ;

	if ( f != disap_arc ) 
		// ERRO de busca iterador do arco...
		return ;

	// arco vizinho anterior...
	ant--;
	if ( ant != parcs.end() )
		a = ant->This() ;

	// arco vizinho posterior...
	post++;  // arco posterior found
	if ( post != parcs.end() )
		p = post->This() ;
		
	//--- Removendo a turma ---//
	
	// 1- Remove o arco do meio do Evento que esta sendo manipulado e
	//  todos os Eventos de Circulo que o referenciam
	// ...antes, remove o Evento de Circulo atual?????

	// apaga o desenho e remove Evento de Circulo
	if ( show_circle )
		f->GetEvtCirculo()->UnDraw() ;

	equeue->Pop() ;
	
	// 2.1 - Remove o (possivel) evento associado ao arco esquerdo de Alfa //
	if ( a != NULL )
	{
		if ( a->GetEvtCirculo() != NULL )
		{
			// remover o evento de circulo associado ao arco da Fila de Eventos
			if ( show_circle ) a->UnDraw();
			equeue->RemoveForEvtCircle (a->GetEvtCirculo());
			// marca o evento de circulo ado arco como NIL
			a->SetEvtCirculo(NULL) ;
		}
	}

	// 2.2 - Remove o (possivel) evento associado ao arco edireito de Alfa //
	if ( p != NULL  )
	{
		if ( p->GetEvtCirculo() != NULL )
		{
			// remover o evento de circulo associado ao arco da Fila de Eventos
			if ( show_circle ) p->UnDraw() ;
			equeue->RemoveForEvtCircle (p->GetEvtCirculo());
			// marca o evento de circulo do arco como NIL
			p->SetEvtCirculo(NULL) ;
		}
	}

	// 3 - Processa o vertice de Voronoi, encerrando os edges terminantes e criando o 
	//     novo edge sainte e atualizando as referencias entre si.

	HandleVertex(e, a, f, p);

	// 4 - Apaga e deleta o arco e recalcula os breakpoints!
	if ( show_beach )
		f->UnDraw();	

	parcs.erase(found) ;

	CalcBreakPoints();

	// 5 - Verificar a ocorrencia de novos eventos de Circulo na vizinhancca do arco removido, 
	//     tendo o antigo arco anterior (a), e o antigo arco posterior (p) como arcos
	//     centrais. 
	
	//--- arco a como arco central (decrementa o iterador de a (ant)) ---//
	// OBS: o anterior de p eh a!
	if ( a != NULL )
	{
		ant = FindArcIterator(a) ;
		post = ant ;

		if ( ant == first )
			return; // nao temos tres arcos com a no meio!!!!
		ant--;
		
		c = CalcCircleEvents (ant) ;
		if ( c != NULL )
				AddEvtCircle(c);
	}

	//--- arco p como arco central (decrementa o iterador de p (post), porem ant == --post!!!) ---//
	if ( p != NULL )
	{
		c = CalcCircleEvents (post) ;
		if ( c != NULL )
				AddEvtCircle(c);
	}

	return;
}

///////////////////////////////////////////////////////////////////////////////
// @@ AddEdge()
// Adiciona o edge, sempre associado cao BreakPoint esquerdo do seeu arco dono.
///////////////////////////////////////////////////////////////////////////////
CEdge *CBeachLine::AddEdge(DPoint bp_orig, DPoint bp_dest, CEvtSite *s_l, CEvtSite *s_r)
{
	CEdge *edge, *edge_, *edge_twin, *edge_twin_ ;
	list<CEdge>::iterator i_e ;

	edge = new CEdge(Plano);		
	edge->SetOrig(bp_orig) ;
	edge->SetDest(bp_dest) ;

	i_e =  edgelist->insert(edgelist->begin(), *edge);
	delete edge ;
	edge_ = i_e->This() ;

	// cria o twin do edge esquerdo...
	edge_twin = new CEdge(Plano);
	i_e =  edgelist->insert(edgelist->begin(), *edge_twin);
//	delete edge_twin ;
	edge_twin_ = i_e->This() ;
		
	edge_->SetTwin(edge_twin_);
	edge_twin_->SetTwin(edge_);

	delete edge_twin ;

	// Seta as faces/sites  esqeurdas 
	edge_->SetLeftSite(s_l);
	edge_twin_->SetLeftSite(s_r);
		
	return edge_ ;
}


///////////////////////////////////////////////////////////////////////////////
// @@ AddVertex()
// Adiciona o vertice e assinala o edge incidente.
///////////////////////////////////////////////////////////////////////////////
CVertex *CBeachLine::AddVertex(DPoint center, CEdge *e)
{
	CVertex *v ;
	list<CVertex>::iterator i_v ;

	v = new CVertex(Plano, center, e);		

	i_v =  vertexlist->insert(vertexlist->begin(), *v);
	delete v ;

	return i_v->This() ;
}


///////////////////////////////////////////////////////////////////////////////
// @@ AddFacet()
// Adiciona a face de Voronoi - Voronoi Cell
///////////////////////////////////////////////////////////////////////////////
CFacet *CBeachLine::AddFacet(CEvtSite *s)
{
	CFacet *f ;
	list<CFacet>::iterator i_f ;

	f = new CFacet(Plano, s) ;

	i_f =  facetlist->insert(facetlist->begin(), *f);

	delete f ;

	return i_f->This() ;
}


///////////////////////////////////////////////////////////////////////////////
// @@ AddVertex()
// Adiciona o vertice e assinala o edge incidente.
///////////////////////////////////////////////////////////////////////////////
CVertex *CBeachLine::AddVertex(DPoint center, CEdge *e, vertextype t)
{
	CVertex *v ;
	list<CVertex>::iterator i_v ;

	v = new CVertex(Plano, center, e, t);		

	i_v =  vertexlist->insert(vertexlist->begin(), *v);
	delete v ;

	return i_v->This() ;
}

///////////////////////////////////////////////////////////////////////////////
// @@ HandleVertex()
// Encerra os edges dos BP em desaparecimento do  evento de circulo e cria o novo
// edge para o novo BP, cria o novo Vertice de Voronoi e ajusta ponteiros.
// ecircle eh o evento de circulo em processamento, a eh o arco anterior ao arco
// que esta desaparecendo (f) e p eh o posterior
///////////////////////////////////////////////////////////////////////////////
void CBeachLine::HandleVertex(CEvtCircle *ecircle, CParArc *a, CParArc *f, CParArc *p)
{
	CVertex *v ;
	list<CVertex>::iterator i_v ;
	CEdge *e_n, *e_l, *e_r, *e_c;
	CEvtSite *sa, *sf, *sp  ;

	//---pega os  sites dos arcos---//
	sa = a->GetSite();
	sf = f->GetSite();
	sp = p->GetSite();

	//--- Cria o novo edge do novo brekpoint ---//
	DPoint center;
	center.x = ecircle->GetC().x;
	center.y = ecircle->GetC().y;
	
	// a Orig do edge eh fixa no centro do evento de circulo (x0, y0) e o Dest fica sob 
	// responsabilidade do arco, que esta a direita (atraves do seu BP_e)
	e_n = AddEdge(center, p->GetBreakPoints().first, p->GetSite(), a->GetSite() );

	// salva o destino do edge que esta no BP_r do arco a direita do que vai desaparecer
	e_c = p->GetRightEdge();
	// ajusta o novo edge para ser conduzido pelo arco a direita...
	p->SetRightEdge(e_n);
	
	//--- Cria o vertice de Voronoi ---//
	// cria o vertice com o ponto do centro do circulo do evento

	v = AddVertex(center, e_n); 

	// --- Fecha o destino do edge que conuzido pelo arco a direita do que vai desaparecer---//
	if ( e_c != NULL )
		e_c->SetDest(v) ;
	// --- Ajusta a origem do novo edge ---//
	e_n->SetOrig(v) ;

	//---Encerra os edges incidentes relativos aos 2 breakpoints que irao desaparecer:

	// O edge com o Dest atrelado ao BP first do arco que ira desaparecer 
	e_l = f->GetRightEdge(); 	
	if ( e_l != NULL )
	{
		// ajusta o endpoint do edge
		e_l->SetDest(v);

		// encadeia o edge: no sentido anti-horario, o novo edge eh o PREV do edge esquerdo.
		e_l->SetPrev(e_n);
		e_n->SetNext(e_l);
		// apaga o edge do arco...
		f->SetRightEdge(NULL);

	}

	// O edge com o Orig atrelado ao arco a direita do arco que ira desaparecer.
	e_r = p->GetLeftEdge();
	if ( e_r != NULL )
	{
		// ajusta o endpoint do edge
		e_r->SetOrig(v);

		// encadeia o edge: no sentido anti-horario, o novo edge eh o NEXT do edge direito.
		e_r->SetNext(e_n);
		e_n->SetPrev(e_r);
		// apaga o edge do arco...
		p->SetLeftEdge(NULL);
	}

}



void CBeachLine::Draw()
{
	if ( show_beach )
	{

		UnDraw () ;

		multiset<CParArc>::iterator first = parcs.begin() ;
		multiset<CParArc>::iterator last  = parcs.end() ;

		while ( first != last ) 
		{
			first->Draw() ;
			first++; 
		}
	}
}

void CBeachLine::UnDraw()
{	
	if ( show_beach )
	{
		multiset<CParArc>::iterator first = parcs.begin() ;
		multiset<CParArc>::iterator last  = parcs.end() ;

		while ( first != last ) 
		{
			first->UnDraw() ;
			first++;
		}
	}
}



void CBeachLine::Debug()
{

	FILE *fp ;
	time_t t;
	struct tm *st;

	if ( (fp = fopen ("debug.txt", "a")) == NULL )
	{
		AfxMessageBox("Erro na abertura do arquivo de log.") ;
		return ;
	}

	multiset<CParArc>::iterator first = parcs.begin() ;
	multiset<CParArc>::iterator last  = parcs.end() ;

	time(&t);
	st = localtime(&t);

	fprintf (fp, "\n\n%s \t\n",	asctime(st)) ;

	fprintf (fp, "ARCOS:\n\n") ;

	int i = 0 ;
	int key = 0, last_key = 0 ;

	while ( first != last ) 
	{
		pair<DPoint, DPoint> bp ;
		char *mark ;

		bp = first->GetBreakPoints() ;

		if ( key < last_key ) 
			mark = "*** ";
		else
		{
			mark = "";
			last_key = key ;
		}

		fprintf (fp, 
		"%spos[%d] Key(%.2E) :site=(%d,%d), BPL=(%.2E,%.2E) BPR=(%.2E,%.2E) em (%p), Y=%d\n",
		mark,
		i,
		first->GetMidPoint(),			
		
		first->GetP1().x, first->GetP1().y,

		bp.first.x, bp.first.y, bp.second.x, bp.second.y,
		first->This(),
		GetY());

		first++; 
		i++ ;
	}

	fprintf (fp, "\nEVENTOS:\n") ;

	CEvt *evt = new CEvt() ;
	priority_queue<CEvt> evtq_  ;

	i = 0 ;

	while ( ! equeue->Empty() ) 
	{
		*evt = equeue->Top();

		if ( evt->IsSiteEvt() )
		{
			fprintf (fp, 
			"pos[%d]:site=(%d,%d) EVENTO DE SITE em %p Y=%d\n",
			i,	evt->GetP1().x, evt->GetP1().y, evt->GetEvt(), GetY()) ;

		}
		if ( evt->IsCircleEvt() )
		{			
			fprintf (fp, 
			"pos[%d]: Pto do evt(%d, %d)  site do arco=(%d,%d) em (%p), EVENTO DE CIRCULO em (%p) Y=%d\n",
			i,	
			evt->GetP1().x, evt->GetP1().y, 
			((CEvtCircle *)evt->GetEvt())->GetArco()->GetP1().x,
			((CEvtCircle *)evt->GetEvt())->GetArco()->GetP1().y,
			((CEvtCircle *)evt->GetEvt())->GetArco(),
			evt->GetEvt(),
			GetY() ) ;
		}

		i++ ;

		equeue->Pop();				
		evtq_.push(*evt) ;		
	}

	while ( ! evtq_.empty()  )
	{
		equeue->Push(evtq_.top());
		evtq_.pop();		
	}

	delete evt ;

	fprintf (fp, "\nEDGES:\n") ;
	CEdge *e ;
	list<CEdge>::iterator efirst = edgelist->begin();
	list<CEdge>::iterator elast  = edgelist->end();

	i = 0;
	
	while ( efirst != elast )
	{
		e = efirst->This();

		fprintf (fp, 
		"edge[%d]:(%p) TWIN:(%p) De (%.2E, %.2E) a (%.2E, %.2E) DRW=%d, Orig=%p Dest=%p Prev=%p Nex=%p Left=%p  Y=%d\n",
		i,	
		e,
		e->GetTwin(),
		e->GetPointOrig().x, e->GetPointOrig().y,
		e->GetPointDest().x, e->GetPointDest().y,
		e->IsDrawable(),
		e->GetOrig(),
		e->GetDest(),
		e->GetPrev(),
		e->GetNext(),
		e->GetFacet(),
		GetY() ) ;

		efirst++;
		i++;
	}


	fprintf (fp, "\nVERTICES:\n") ;
	CVertex *v ;
	list<CVertex>::iterator vfirst = vertexlist->begin();
	list<CVertex>::iterator vlast  = vertexlist->end();

	i = 0;
	
	while ( vfirst != vlast )
	{
		v = vfirst->This();

		fprintf (fp, 
		"vertex[%d]:(%p) em (%.2E, %.2E) IncEdge=%p tipo=%d Y=%d\n",
		i,	
		v,
		v->GetPoint().x, v->GetPoint().y,
		v->GetIncEdge(),
		v->GetType(),
		GetY() ) ;

		vfirst++;
		i++;
	}




	fclose (fp) ;
}

void CBeachLine::Debug( char *s)
{

	FILE *fp ;
	time_t t;
	struct tm *st;

	if ( (fp = fopen ("debug.txt", "a")) == NULL )
	{
		AfxMessageBox("Erro na abertura do arquivo de log.") ;
		return ;
	}

	time(&t);
	st = localtime(&t);

	fprintf (fp, "\n\n%s \t\n",	asctime(st)) ;

	fprintf (fp, "%s\n", s) ;


	fclose (fp) ;
}


// EOF
