// DesenhoDoc.cpp : implementation of the CDesenhoDoc class
//

#include "stdafx.h"
#include "Desenho.h"

#include "DesenhoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDesenhoDoc

IMPLEMENT_DYNCREATE(CDesenhoDoc, CDocument)

BEGIN_MESSAGE_MAP(CDesenhoDoc, CDocument)
	//{{AFX_MSG_MAP(CDesenhoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDesenhoDoc construction/destruction

CDesenhoDoc::CDesenhoDoc()
{
	// TODO: add one-time construction code here

}

CDesenhoDoc::~CDesenhoDoc()
{
	Clear() ;
}

BOOL CDesenhoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	Clear() ;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDesenhoDoc serialization

void CDesenhoDoc::Serialize(CArchive& ar)
 {
     m_arrayObjDes.Serialize(ar);

     if (ar.IsStoring())
     {
     // TODO: add storing code here
     }
     else
     {
     // TODO: add loading code here
     } 
 }



/////////////////////////////////////////////////////////////////////////////
// CDesenhoDoc diagnostics

#ifdef _DEBUG
void CDesenhoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDesenhoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDesenhoDoc commands

void CDesenhoDoc::Add(CObjDes *pObjDes)
{
	// FDF, 30-JAN-2001
	if ( pObjDes )
		m_arrayObjDes.Add( (CObject *) pObjDes); 
	else
		Beep (350, 1000) ;
}

void CDesenhoDoc::Clear()
{
	UINT n = GetSize(); 
	for(UINT i=0; i<n; i++ ) { 
		CObjDes *pObjDes = (CObjDes *) m_arrayObjDes[i]; 
		delete (CObject *) pObjDes; 

	}; 
	m_arrayObjDes.RemoveAll(); 
}

UINT CDesenhoDoc::GetSize()
{
	return m_arrayObjDes.GetSize() ; 
}

CObjDes * CDesenhoDoc::Get(UINT index)
{
	if ( index < GetSize() ) 
		return (CObjDes *) m_arrayObjDes[index]; 
	else 
		return NULL; 
}

// EOF
