// EventQueue.h: interface for the CEventQueue class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EVENTQUEUE_H__660CE957_E3B6_4A45_B566_9D5A3031C13B__INCLUDED_)
#define AFX_EVENTQUEUE_H__660CE957_E3B6_4A45_B566_9D5A3031C13B__INCLUDED_


#include "Evt.h"

#include <queue>
#include <deque>
#include <vector>
#include <functional>
#include <set>

using namespace std ;

#include "ParArc.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CEventQueue : public CObject  
{
public:
	CEventQueue();
	virtual ~CEventQueue();

	void SetY(int y);
	void Clear();
	void Push (CEvt &e);
	CEvt& Top ();
	void Pop ();
	void RemoveForEvtCircle(CObjDes *e);
	void RemoveEvtCircleForArc(CParArc *a);
	int  Size ();
	bool Empty ();

protected:

	priority_queue<CEvt>	evtq ;	// Fila de eventos

};

#endif // !defined(AFX_EVENTQUEUE_H__660CE957_E3B6_4A45_B566_9D5A3031C13B__INCLUDED_)


// EOF