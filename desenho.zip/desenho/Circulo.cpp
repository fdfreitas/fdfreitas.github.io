// Circulo.cpp: implementation of the CCirculo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Circulo.h"
#include <math.h>

#include <string>
using namespace std ;


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define Pi	3.1415926535897932384626433832795

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCirculo::CCirculo()
{
	SetCirculo() ;
}

CCirculo::~CCirculo()
{
}

void CCirculo::SetP1(CPoint p)
{
	p1 = p ;
	// calcula o retangulo a partir dos pontos
	CalcRect() ;

}

void CCirculo::SetP2(CPoint p)
{
	p2 = p ;
	// calcula o retangulo a partir dos pontos
	CalcRect() ;
}


CPoint CCirculo::GetC(void)
{
	return c ;	
}

UINT CCirculo::GetR(void)
{
	return r ;
}

void CCirculo::SetCirculo()
{
	m_tipo = C_CIRCULO ;	
}

void CCirculo::SetElipse()
{
	m_tipo = C_ELIPSE ;
}

void CCirculo::CalcRect(void)
{
	CPoint _point ;

	if ( m_tipo == C_CIRCULO )
	{		
		// calcula coordenadas para o novo circulo
		double a = p2.y - p1.y ;
		double b = p2.x - p1.x ;

		// Calcula o raio do circulo em funccao do raio arrastado com o mouse
		double raio = 0.5 * sqrt (pow(a, 2) + pow (b, 2)) ;

		// Calcula o centro da circunferencia em funccao do raio arrastado com o mouse,
		// sempre usando P1 como "vertice"
		c.x = p1.x + (int) (b / 2.0) ;
		c.y = p1.y + (int) (a / 2.0) ; 
		r = raio ;
		
		// calcula os vertices do retangulo da circunferencia
		rect.SetRect (c.x - r, c.y - r, c.x + r, c.y + r) ;  	
	}
	else if ( m_tipo == C_ELIPSE )
		//rect.SetRect (c.x - r, c.y - r, c.x + r, c.y + r) ;  	
		rect.SetRect (p1.x, p1.y, p2.x, p2.y) ;  	

}

void CCirculo::Draw(CDC *pDC)
{
	// desenha a circunferencia
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 

//	pDC->SetROP2(R2_COPYPEN); 
	pDC->SetROP2(R2_NOTXORPEN); 

	pDC->Ellipse(rect) ;

	pDC->SelectObject(pOldPen); 
}

void CCirculo::UnDraw(CDC *pDC)
{

	// desenha a circunferencia
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 

	// pDC->SetROP2(R2_NOTXORPEN); 
	pDC->SetROP2(R2_NOTXORPEN); 

	pDC->Ellipse(rect) ;

	pDC->SelectObject(pOldPen); 
}


IMPLEMENT_SERIAL(CCirculo,CObject,1);
void CCirculo::Serialize(CArchive &ar) {

    CObject::Serialize(ar);
    if(ar.IsStoring() ) {

	   ar << (ULONG) m_crCor << m_nLargura;
       ar << (ULONG) rect.TopLeft().x << rect.TopLeft().y <<
		      rect.BottomRight().x << rect.BottomRight().y ;       
    } 
	else 
	{ 
       ar >> (ULONG) m_crCor ;
	   ar >> m_nLargura;
	   UINT a, b, c, d ;

	   ar >> a ;
	   ar >> b ;
	   ar >> c ;
	   ar >> d ;		   

	   rect.SetRect (a, b, c, d) ;
	   	   
    } 
}

// EOF
