// DesenhoView.h : interface of the CDesenhoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DESENHOVIEW_H__1B992C5A_182A_422E_8F4F_2B31AD6A6B61__INCLUDED_)
#define AFX_DESENHOVIEW_H__1B992C5A_182A_422E_8F4F_2B31AD6A6B61__INCLUDED_

#include "Ferramenta.h"	// Added by ClassView
#include "Delaunay.h"	

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



//class CDelaunay;

class CDesenhoView : public CScrollView
{
protected: // create from serialization only
	CDesenhoView();
	DECLARE_DYNCREATE(CDesenhoView)

// Attributes
public:

	virtual ~CDesenhoView();
	CDesenhoDoc* GetDocument();
	void DelaunayStart() ;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDesenhoView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:


#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CFerramenta *m_pFerramenta;
	CDelaunay	*m_pDelaunay;


// Generated message map functions
protected:	
//	CObjDes *m_pObjDesTemp;
//	BOOL m_bTracando;
//	CPoint m_ptUltimoPonto;

	//{{AFX_MSG(CDesenhoView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnToolsFreehand();
	afx_msg void OnToolsPoligonal();
	afx_msg void OnToolsRetangulo();
	afx_msg void OnToolsCirculo();
	afx_msg void OnToolsTexto();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnToolsLinha();
	afx_msg void OnToolsRefresh();
	afx_msg void OnToolsPonto();
	afx_msg void OnDelaunayStart();
	afx_msg void OnDelaunayStop();
	afx_msg void OnDelaunayClear();
	afx_msg void OnDelaunayYStep();
	afx_msg void OnDelaunayEventStep();
	afx_msg void OnDelaunayShowVoronoi();
	afx_msg void OnDelaunayShowDelaunay();
	afx_msg void OnDelaunayShowBeach();
	afx_msg void OnDelaunayShowCircle();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()	

	CDC *pDC ;	
	bool DELAUNAY_STEP ;

private:

};

#ifndef _DEBUG  // debug version in DesenhoView.cpp
inline CDesenhoDoc* CDesenhoView::GetDocument()
   { return (CDesenhoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DESENHOVIEW_H__1B992C5A_182A_422E_8F4F_2B31AD6A6B61__INCLUDED_)
