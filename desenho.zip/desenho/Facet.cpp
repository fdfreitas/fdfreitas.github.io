// Facet.cpp: implementation of the CFacet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Facet.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFacet::CFacet()
{

}

CFacet::~CFacet()
{

}

CFacet::CFacet(CPlane *plano, CEvtSite *s)
{
	SetSite(s) ;
}

CFacet *CFacet::This()
{
	return this ;
}



void CFacet::SetSite(CEvtSite *s)
{
	site = s ;
}


CEvtSite *CFacet::GetSite()
{
	return site ;
}


// EOF