// Plane.h: interface for the CPlane class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLANE_H__F8C3AF61_F130_4D10_B467_56FE0CB290F0__INCLUDED_)
#define AFX_PLANE_H__F8C3AF61_F130_4D10_B467_56FE0CB290F0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Bounds do Plano
enum planebound { PLANE_BOUND_INNER, PLANE_BOUND_LEFT, PLANE_BOUND_TOP, PLANE_BOUND_RIGHT, 
				  PLANE_BOUND_BOTTOM} ;

class CPlane : public CObject  
{
public:
	CPlane();
	CPlane(CPoint ul, CPoint lr, CDC *pdc);
	virtual ~CPlane();

	// Seccao NICE CLASS!!! 
	CPlane(const CPlane& p)
	{		
		pDC= p.pDC ;	// Ponteiro para o contexto do GDI (CDC)
		UL = p.UL ;		// Upper Left point do Plano
		LR = p.LR;		// Lower Right point do Plano
	}

	CPlane& operator= (const CPlane& p) 
	{
		pDC= p.pDC ;
		UL = p.UL ;
		LR = p.LR;

		return *this;
	}
	// fim NICE CLASS!!!!  


	// Ambiente grafico....
	CDC *pDC ;
	CPoint UL;
	CPoint LR;

};

#endif // !defined(AFX_PLANE_H__F8C3AF61_F130_4D10_B467_56FE0CB290F0__INCLUDED_)
