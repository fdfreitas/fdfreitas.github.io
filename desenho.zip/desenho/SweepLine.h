// SweepLine.h: interface for the CSweepLine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SWEEPLINE_H__EF2C849B_5FF5_4C96_8A31_D5DFEEA424C4__INCLUDED_)
#define AFX_SWEEPLINE_H__EF2C849B_5FF5_4C96_8A31_D5DFEEA424C4__INCLUDED_

#include "Plane.h"
#include "Linha.h"
#include "Texto.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ObjDes.h"

class CSweepLine : public CObject  
{
public:
	CSweepLine();
	CSweepLine(CPlane *p);
	virtual ~CSweepLine();
	void SetPlane(CPlane *plano);
	void SetY(int y);
	void Clear ();
	void UnDraw();
	void Draw();

protected:

	CPlane *Plano ;    // Plano....
	CLinha *linha ;
	CTexto *legenda ;

};

#endif // !defined(AFX_SWEEPLINE_H__EF2C849B_5FF5_4C96_8A31_D5DFEEA424C4__INCLUDED_)

// EOF