// Evt.cpp: implementation of the CEvt class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Evt.h"

#include <string>

using namespace std; 

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEvt::CEvt()
{

}

CEvt::~CEvt()
{

}

CEvt::CEvt(CObjDes &o)
{

	// ATENCCAO: verificar se nao basta copiar o ponteiro ao inves de criar un novo obj
//	evt = new CObjDes (o) ;

	// Apontador para o Evento de interesse (CEvtSite ou CEvtCircle)
	evt = &o ;

	
	// Registro do tipo do Evento de interesse (CEvtSite ou CEvtCircle)
	const type_info& t = typeid(o) ;     
	string s = t.name() ;

	if ( ! strcmp (s.c_str(), "class CEvtSite") ) 
	
		tipoevt = TIPO_EVT_SITE;
	
	else if ( ! strcmp (s.c_str(), "class CEvtCircle") ) 
	
		tipoevt = TIPO_EVT_CIRCLE ;

}


bool CEvt::IsSiteEvt()
{
	return ( tipoevt == TIPO_EVT_SITE ) ; 

}

bool CEvt::IsCircleEvt()
{
	return ( tipoevt == TIPO_EVT_CIRCLE ) ; 
}


CObjDes *CEvt::GetEvt()
{
	return evt;
}

CPoint CEvt::GetP1()
{
	return evt->GetP1() ;
}

CPoint CEvt::GetP2()
{

	return evt->GetP2() ;
}

int CEvt::GetY()
{

	return evt->GetP1().y ;
}

