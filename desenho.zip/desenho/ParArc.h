// ParArc.h: interface for the CParArc class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PARARC_H__18EFE5E0_1D11_4BAA_96E4_DDF4DCA385B5__INCLUDED_)
#define AFX_PARARC_H__18EFE5E0_1D11_4BAA_96E4_DDF4DCA385B5__INCLUDED_

#include "Plane.h"
#include "EvtSite.h"
#include "EvtCircle.h"
#include "Edge.h"

#include <utility>
#include <algorithm>
using namespace std;
/*
typedef struct {
	double x ;
	double y;
} DPoint;
*/

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CParArc : public CObjDes 
{
public:
	CParArc();
	virtual ~CParArc();
	CParArc(CEvtSite &s, CPlane *p);
	CParArc *CParArc::This() ;

	void SetY(int y) ;
	int GetY() ;
	void SetBreakPoints(pair<DPoint, DPoint> &p) ;
	pair<DPoint, DPoint>& GetBreakPoints() ;
	double GetMidPoint();
	CPoint GetP1() ;
	CEvtSite *GetSite() ;
	void SetEvtCirculo(CEvtCircle *e) ;
	CEvtCircle *CParArc::GetEvtCirculo() ;

	void SetLeftEdge(CEdge *e) ;
	CEdge *GetLeftEdge() ;

	void SetRightEdge(CEdge *e) ;
	CEdge *GetRightEdge() ;

	
	void Draw();
	void UnDraw();
	void UnDrawResetMem();

	// calculos com as parabolas
	double K ();
	double W ();
	double BETA (double x) ;
	double GetParVal(double x) ;
	pair<double, double> CalcRaizes();
	pair<double, double> CalcIntersecao (CParArc *a);

	// Seccao NICE CLASS!!! 
	CParArc(const CParArc& a)
	{		
		Plano = a.Plano ;
		site = a.site ;
		Y = a.Y ;
		Y_ = a.Y_ ;
		BreakPoints = a.BreakPoints ;
		BreakPoints_ = a.BreakPoints_ ;
		midpoint = a.midpoint ;
		evtcirculo = a.evtcirculo;
		edge_l = a.edge_l;
		edge_r = a.edge_r;
	}

	CParArc& operator= (const CParArc& a) 
	{
		Plano = a.Plano ;
		site = a.site ;
		Y = a.Y ;
		BreakPoints = a.BreakPoints ;
		midpoint = a.midpoint ;
		evtcirculo = a.evtcirculo;
		edge_l = a.edge_l;
		edge_r = a.edge_r;

		return *this;
	}

	bool operator< (CParArc const &a) const
	{
		// ATENCCAO!! Na BeachLine, os arcos sao ordenados por X ,por isso
		// nao posso usar o operator< do EventSite que eh ordenado por Y

		// ordena pelo ponto medio da projeccao da parabola

		//return ( BreakPoints.first.x   + (BreakPoints.second.x - BreakPoints.first.x) / 2 < 
		//	     a.BreakPoints.first.x + (a.BreakPoints.second.x - a.BreakPoints.first.x)  );

		return ( midpoint < a.midpoint );
	}

	bool operator== (CParArc const &a) const
	{
		return ( site == a.site ) ;	
	}

	bool operator!= (CParArc const &a) const
	{
		return ( site != a.site ) ;	
	}
	// fim NICE CLASS!!!!  

protected:

	void CParArc::_Draw(pair<DPoint, DPoint> bp);

	CPlane *Plano;				// Plano do diagrama...
	CEvtSite	site ;			// site gerador do arco parabolico
	CEvtCircle *evtcirculo ;	// Ponteiro para o (eventual) evento de circulo do arco
	int			Y ;				// Posiccao da SweepLine 
	int			Y_ ;			// Posiccao anterior da SweepLine - PARA APAGAR O DESENHO
	pair<DPoint, DPoint> BreakPoints ; // BreakPoints do Arco.
	pair<DPoint, DPoint> BreakPoints_ ; // BreakPoints do Arco antigo - PARA APAGAR O DESENHO.
	double               midpoint ;    // ponto medio dos BreakPoints

	CEdge *edge_l;				// Voronoi edge associado ao breakpoint esquerdo do arco
	CEdge *edge_r;				// Voronoi edge associado ao breakpoint direito do arco
};

#endif // !defined(AFX_PARARC_H__18EFE5E0_1D11_4BAA_96E4_DDF4DCA385B5__INCLUDED_)
