// DesenhoDoc.h : interface of the CDesenhoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DESENHODOC_H__191A9D6A_F33D_443E_A3BA_38FB441A6710__INCLUDED_)
#define AFX_DESENHODOC_H__191A9D6A_F33D_443E_A3BA_38FB441A6710__INCLUDED_

#include "ObjDes.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDesenhoDoc : public CDocument
 {
 protected: // create from serialization only
 CDesenhoDoc();
    DECLARE_DYNCREATE(CDesenhoDoc)

 // Attributes
 public:

 // Operations
 public:

 // Overrides
 // ClassWizard generated virtual function overrides
 //{{AFX_VIRTUAL(CDesenhoDoc)
 public:
     virtual BOOL OnNewDocument();
     virtual void Serialize(CArchive& ar);
//}}AFX_VIRTUAL

 // Implementation
 public:
     virtual ~CDesenhoDoc();
 #ifdef _DEBUG
     virtual void AssertValid() const;
     virtual void Dump(CDumpContext& dc) const;
 #endif
     
	 void Add(CObjDes *pObj);
	 void Clear(); 
     UINT GetSize(); 
	 CObjDes *Get(UINT index); 

 protected:

 // Generated message map functions
 protected:
     CObArray m_arrayObjDes;

     //{{AFX_MSG(CDesenhoDoc)
     // NOTE - the ClassWizard will add and remove member functions here.
     // DO NOT EDIT what you see in these blocks of generated code !
     //}}AFX_MSG
    DECLARE_MESSAGE_MAP()
 };


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DESENHODOC_H__191A9D6A_F33D_443E_A3BA_38FB441A6710__INCLUDED_)
