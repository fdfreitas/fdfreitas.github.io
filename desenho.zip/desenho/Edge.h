// Edge.h: interface for the CEdge class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EDGE_H__034AD622_F958_412D_B7F7_FE2C53E01D4C__INCLUDED_)
#define AFX_EDGE_H__034AD622_F958_412D_B7F7_FE2C53E01D4C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Linha.h"
#include "Plane.h"
#include "Vertex.h"
#include "EvtSite.h"

#include <utility>
using namespace std;


class CFacet;

class CEdge : public CObjDes
{
public:
	CEdge();
	CEdge(CPlane *p);
	
	virtual ~CEdge();

	CEdge* This();

	void SetOrig(CVertex *v);
	void SetOrig(DPoint p);
	CVertex *GetOrig();
	DPoint GetPointOrig();

	void SetDest(CVertex *v);
	void SetDest(DPoint p);
	CVertex *GetDest();
	DPoint GetPointDest();

	void SetTwin(CEdge *e);
	CEdge *GetTwin();

	void SetPrev(CEdge *e);
	CEdge *GetPrev();

	void SetNext(CEdge *e);
	CEdge *GetNext();

	void SetFacet(CFacet *f);
	CFacet *GetFacet();

	void SetLeftSite(CEvtSite *s);
	CEvtSite *GetLeftSite();


	void SetDrawable(bool b);
	bool IsDrawable();

	void Draw();
	void UnDraw();
	void SetPoints(pair<DPoint,DPoint> p);
	pair<DPoint,DPoint> GetPoints();


	// Seccao NICE CLASS!!! 
	CEdge(const CEdge& e)
	{		
		orig   = e.orig;
		dest  = e.dest;
		twin  = e.twin;
		prev  = e.prev;
		next  = e.next;
		left  = e.left;
		left_site = e.left_site ;

		Plano = e.Plano;
		linha = e.linha;
		pontos = e.pontos;
		drawable = e.drawable;

		// nao sei como chamar o = do ObjDes
		m_crCor = e.m_crCor;
		m_nLargura = e.m_nLargura; 
		p1 = e.p1; 
		p2 = e.p2;
	}

	CEdge& operator= (const CEdge& e) 
	{
		orig   = e.orig;
		dest  = e.dest;
		twin  = e.twin;
		prev  = e.prev;
		next  = e.next;
		left  = e.left;
		left_site = e.left_site ;

		Plano = e.Plano;		
		linha = e.linha;
		pontos = e.pontos;
		drawable = e.drawable;

		// nao sei como chamar o = do ObjDes
		m_crCor = e.m_crCor;
		m_nLargura = e.m_nLargura; 
		p1 = e.p1; 
		p2 = e.p2;

		return *this;
	}
/*
	bool operator< (CEdge const &e) const
	{
		return ( GetP1().y < a.GetP1().y );
	}
*/
	bool operator== (CEdge const &e) const
	{
		return ( orig == e.orig && dest == e.dest ) ;	
	}

	bool operator!= (CEdge const &e) const
	{
		return ( !(orig == e.orig && dest == e.dest) ) ;	
	}
	// fim NICE CLASS!!!!  


private:
	CVertex *orig;	// Vertice origem 
	CVertex *dest;	// Vertice destino 

	CEdge	*twin;	// Edge gemeo 	
	CEdge	*prev;	// Edge anterior da face esquerda no sentido anti-horario
	CEdge	*next;	// Edge posterior da face esquerda no sentido anti-horario

	CFacet	*left;	// Face esquerda do edge

	CEvtSite *left_site;	// Site esquerdo do edge


	CPlane *Plano;	// Plano do diagrama...
	CLinha linha;	// Desenho do edge

	pair<DPoint, DPoint> pontos ;   // coordenadas do edge
	pair<DPoint, DPoint> pontos_ ; // ultimo desenho do edge

	bool drawable;		// Flag de liberaccao para desenho
};

#endif // !defined(AFX_EDGE_H__034AD622_F958_412D_B7F7_FE2C53E01D4C__INCLUDED_)

// EOF