// EvtCircle.cpp: implementation of the EvtCircle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "EvtCircle.h"
#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEvtCircle::CEvtCircle()
{
	SetarCor(RGB (200,200, 200)) ;

}

CEvtCircle::~CEvtCircle()
{
}

// constroi a partir de um ObjDes (uso no typecast para Evt->evt)
CEvtCircle::CEvtCircle(CObjDes *e)
{
	SetarCor(RGB (200,200, 200)) ;
}

// constroi a partir de dois pontos do circulo
CEvtCircle::CEvtCircle(CPlane *p, CPoint a, CPoint b)
{
	SetarCor(RGB (200,200, 200)) ;

	Plano = p ;
	p1 = a ;
	p2 = b ;

	CalcRect() ;

	arco = NULL ;
}

// constroi a partir do x0, y0 do centro e raio do circulo
CEvtCircle::CEvtCircle(CPlane *p, double x0, double y0, double r)
{
	SetarCor(RGB (200,200, 200)) ;
	Plano = p ;
	// ATENCCAO: escolherei a radial vertical como pontos do CCirculo,
	// deforma que P1, que sera ordenado na Fila de Eventos seja o 
	// ponto mais abaixo do circulo!

/*
	p1.x = (int) ceil (x0) ;
	p1.y = (int) ceil (y0 + r) ;

	p2.x = (int) p1.x ;
	p2.y = (int) ceil (y0 - r) ;
*/


	p1.x = (int) (x0 + 0.5) ;
	p1.y = (int) (y0 + r + 0.5) ;

	p2.x = p1.x ;
	p2.y = (int) (y0 - r + 0.5) ;


	CalcRect() ;

	arco = NULL ;
}


void CEvtCircle::SetArco(CParArc *a)
{
	arco = a ;
}

CParArc *CEvtCircle::GetArco()
{
	return arco ;
}


void CEvtCircle::Draw()
{
	// desenha a circunferencia
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) Plano->pDC->SelectObject(&pen); 

	Plano->pDC->SetROP2(R2_NOTXORPEN); 

	Plano->pDC->Ellipse(rect) ;

	CPonto p ;
	CPoint point;

	// desenha o centro da circunferencia
	p.SetarCor(m_crCor );
//	p.SetarCor(m_crCor - 30 );
	p.SetP1(c) ;
	p.Draw(Plano->pDC); 

	// desenha o ponto do evento
	point.x = c.x ; 
	point.y = c.y + r ;
	p.SetarCor(m_crCor);
	p.SetP1(point) ;
	p.Draw(Plano->pDC); 


	Plano->pDC->SelectObject(pOldPen); 
}

void CEvtCircle::UnDraw()
{

	// desenha a circunferencia
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) Plano->pDC->SelectObject(&pen); 

	Plano->pDC->SetROP2(R2_NOTXORPEN); 

	Plano->pDC->Ellipse(rect) ;

	CPonto p ;
	CPoint point;

	// desenha o centro da circunferencia
	//p.SetarCor(m_crCor - 30 );
	p.SetarCor(m_crCor);
	p.SetP1(c) ;
	p.Draw(Plano->pDC); 

	// desenha o ponto do evento
	point.x = c.x ; 
	point.y = c.y + r ;
	p.SetarCor(m_crCor);
	p.SetP1(point) ;
	p.Draw(Plano->pDC); 

	Plano->pDC->SelectObject(pOldPen); 
}


// EOF