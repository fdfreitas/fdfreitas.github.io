// SweepLine.cpp: implementation of the CSweepLine class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "SweepLine.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CSweepLine::CSweepLine()
{	
	linha   = new CLinha ;
	legenda = new CTexto ;

	CPoint p ;
	p.x = 0; p.y = 0 ;
	if ( linha ) linha->SetP1(p) ;
	if ( linha ) linha->SetP2(p) ;
}

CSweepLine::CSweepLine(CPlane *p)
{	
	Plano = p ;
	
	linha = new CLinha ;
	legenda = new CTexto ;

	CPoint point ;
	point.x = 0; point.y = 0 ;
	if ( linha ) linha->SetP1(point) ;
	if ( linha ) linha->SetP2(point) ;
}

CSweepLine::~CSweepLine()
{
	delete linha;
	delete legenda;

}


void CSweepLine::SetPlane(CPlane *plano)
{
	Plano = plano ;
	
	linha = new CLinha ;

	CPoint point ;
	point.x = 0; point.y = 0 ;
	if ( linha ) linha->SetP1(point) ;
	if ( linha ) linha->SetP2(point) ;

}

void CSweepLine::SetY(int y)
{
	CPoint p, q ;

	p.x = Plano->UL.x ;
	p.y = y ;

	q.x = Plano->LR.x ;
	q.y = y ;

	UnDraw() ;

	linha->SetP1 (p) ;
	linha->SetP2 (q) ;
	
	q.x = Plano->UL.x;
	q.y = Plano->LR.y+12;
	legenda->SetP1(q);
	Draw() ;
}

void CSweepLine::Clear ()
{
	UnDraw () ;

	SetY(0);
}

void CSweepLine::Draw()
{
	if ( linha->GetP1().y < Plano->LR.y )
		linha->Draw (Plano->pDC) ;	

	char str[50];

	sprintf (str, "Y=%d", linha->GetP1().y );

	legenda->SetTexto (str) ;
	legenda->Draw(Plano->pDC) ;
}

void CSweepLine::UnDraw()
{
	char str[50];
	sprintf (str, "Y=          ");
	legenda->SetTexto (str) ;
	if ( linha->GetP1().y < Plano->LR.y )
		linha->UnDraw (Plano->pDC) ;	
	legenda->UnDraw(Plano->pDC) ;
}


// EOF
