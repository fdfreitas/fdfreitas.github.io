// Linha.cpp: implementation of the CLinha class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Linha.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLinha::CLinha()
{
}

CLinha::~CLinha()
{
}

void CLinha::SetP1(CPoint p)
{
	p1 = p ;
}

CPoint CLinha::GetP1()
{
	return p1  ;
}

void CLinha::SetP2(CPoint p)
{
	p2 = p ;
}

CPoint CLinha::GetP2()
{
	return p2  ;
}


void CLinha::Draw(CDC *pDC)
{
	// desenha a linha
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 
	
	pDC->SetROP2(R2_NOTXORPEN); 

	pDC->MoveTo(p1) ;
	pDC->LineTo (p2) ;

	pDC->SelectObject(pOldPen); 
}

void CLinha::UnDraw(CDC *pDC)
{
	// desenha a linha
	// TODO - Incorporar estilos no traccado
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 

	pDC->SetROP2(R2_NOTXORPEN); 

	pDC->MoveTo(p1) ;
	pDC->LineTo (p2) ;

	pDC->SelectObject(pOldPen); 
}


IMPLEMENT_SERIAL(CLinha,CObject,1);
void CLinha::Serialize(CArchive &ar) {

    CObject::Serialize(ar);
    if(ar.IsStoring() ) {

	   ar << (ULONG) m_crCor << m_nLargura;
       ar << (ULONG) p1.x << p1.y << p2.x << p2.y ;
    } 
	else 
	{ 
       ar >> (ULONG) m_crCor ;
	   ar >> m_nLargura;
	   ar >> p1.x ;
	   ar >> p1.y ;
	   ar >> p2.x ;
	   ar >> p2.y ;	   	   
    } 
}

// EOF
