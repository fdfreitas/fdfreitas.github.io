// Site.h: interface for the CEvtSite class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SITE_H__C66091FA_13DA_4B3F_BCF5_8E8BD98D4199__INCLUDED_)
#define AFX_SITE_H__C66091FA_13DA_4B3F_BCF5_8E8BD98D4199__INCLUDED_


#include "ponto.h"
#include "Evt.h"


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CEvtSite : public CPonto
{
public:
	CEvtSite();
	CEvtSite(CPoint p);
	CEvtSite(CEvtSite *s);
	CEvtSite(CObjDes *e);
	virtual ~CEvtSite();

	// Seccao NICE CLASS!!! 
	CEvtSite(const CEvtSite& site) 
	{
		p1 = site.p1 ;
		p2 = p1 ;
		m_crCor = site.m_crCor ;
		m_nLargura = site.m_nLargura;

	}

	CEvtSite& operator= (const CEvtSite& site) 
	{
		p1 = site.p1 ;
		p2 = site.p1 ;
		m_crCor = site.m_crCor ;
		m_nLargura = site.m_nLargura;
		return *this;
	}

	bool operator< (CEvtSite const &s) const
	{
		return ( p1.y > s.p1.y ) ;	
	}

	bool operator== (CEvtSite const &s) const
	{
		return ( p1.x == s.p1.x && p1.y == s.p1.y ) ;	
	}

	bool operator!= (CEvtSite const &s) const
	{
		return ( ! (p1.x == s.p1.x && p1.y == s.p1.y) ) ;	
	}
	// fim NICE CLASS!!!!  

};

#endif // !defined(AFX_SITE_H__C66091FA_13DA_4B3F_BCF5_8E8BD98D4199__INCLUDED_)

// EOF