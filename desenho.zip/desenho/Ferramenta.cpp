// Ferramenta.cpp: implementation of the CFerramenta class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"

#include "Poligonal.h"
#include "Circulo.h"
#include "Quadrado.h"
#include "Texto.h"
#include "Linha.h"
#include "Ponto.h"

#include "DesenhoDoc.h"

#include "Ferramenta.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFerramenta::CFerramenta()
{
	m_bTracando = FALSE ;
	m_pObjDesTemp = NULL ;
	// m_tipo = FREEHAND ;	
	m_tipo = PONTO ;	

}

CFerramenta::~CFerramenta()
{
	if ( m_pObjDesTemp ) delete m_pObjDesTemp; 
}

CFerramenta::SetTipoDesenho(tipodesenho t)
{
	m_tipo = t ;
}

void CFerramenta::OnLButtonDown(CDesenhoDoc* pDoc, CDC *pDC, UINT nFlags, CPoint point)  
{
	m_bTracando = TRUE; 	 

	switch(m_tipo) 
	{ 
		case FREEHAND: 
			if( m_pObjDesTemp ) delete m_pObjDesTemp ;
			m_pObjDesTemp = new CPoligonal; 
			break; 

		case POLIGONAL: 
			if( m_pObjDesTemp == NULL ) 
				m_pObjDesTemp = (CObjDes *) new CPoligonal; 
			break; 

		case RETANGULO: 
			if( m_pObjDesTemp ) delete m_pObjDesTemp ;
			m_pObjDesTemp = new CQuadrado ;
			break ;

		case CIRCULO:
			if( m_pObjDesTemp ) delete m_pObjDesTemp ;
			m_pObjDesTemp = new CCirculo; 
			break; 

		case LINHA:
			if( m_pObjDesTemp ) delete m_pObjDesTemp ;
			m_pObjDesTemp = new CLinha; 
			break; 

		case TEXTO:
			if( m_pObjDesTemp ) delete m_pObjDesTemp ;
			m_pObjDesTemp = new CTexto; 
			break; 

		case PONTO:
			if( m_pObjDesTemp ) delete m_pObjDesTemp ;
			m_pObjDesTemp = new CPonto (point); 
			m_pObjDesTemp->Draw(pDC) ;

			return ; 

		case DELAUNAY:
			break ;
	}

	m_pObjDesTemp->SetP1(point); 
	m_pObjDesTemp->SetP2(point); 
} 

void CFerramenta::OnMouseMove(CDesenhoDoc* pDoc, CDC *pDC, UINT nFlags, CPoint point)  
{ 
	if ( ! m_bTracando ) return ;

	ASSERT(m_pObjDesTemp); 

	m_pObjDesTemp->UnDraw(pDC) ;

	switch(m_tipo) 
	{ 
		case FREEHAND: 
			m_pObjDesTemp->SetP1(point); 
			break; 

		case POLIGONAL: 

			// m_pObjDesTemp->UnDraw(pDC) ;
			((CPoligonal *)m_pObjDesTemp)->RetirarPonto() ; 

			break ;

		case RETANGULO: 
			// verifica o tipo do retangulo
			if ( nFlags & MK_SHIFT ) 
				((CQuadrado *)m_pObjDesTemp)->SetRetangulo () ;	
			else
				((CQuadrado *)m_pObjDesTemp)->SetQuadrado () ;	
			break; 
 
		case CIRCULO: 
			// verifica o tipo do circulo					
			if ( nFlags & MK_SHIFT ) 
				((CCirculo *)m_pObjDesTemp)->SetElipse () ;	
			else
				((CCirculo *)m_pObjDesTemp)->SetCirculo () ;	

			break; 

		case PONTO: 

			break ;

	}

	m_pObjDesTemp->SetP2 (point) ;		
	m_pObjDesTemp->Draw(pDC) ;
} 

void CFerramenta::OnLButtonUp(CDesenhoDoc* pDoc, CDC *pDC, UINT nFlags, CPoint point)  
{
	if ( ! m_bTracando ) return ;

	switch(m_tipo) 
	{ 
		case FREEHAND: 
		case RETANGULO: 
		case CIRCULO: 
		case LINHA: 
		case PONTO: 
			m_bTracando = FALSE; 
			if ( m_pObjDesTemp ) 
				pDoc->Add(m_pObjDesTemp); 
			m_pObjDesTemp = NULL; 
			break; 
	} 
} 

void CFerramenta::OnLButtonDblClk(CDesenhoDoc* pDoc, CDC *pDC, UINT nFlags, CPoint point)  
{ 
	if ( ! m_bTracando ) return ;

	if( m_tipo == POLIGONAL ) 
	{ 
		if ( m_pObjDesTemp ) 
			pDoc->Add(m_pObjDesTemp);
		
		m_pObjDesTemp = NULL; 
		m_bTracando = FALSE; 
	}

}

void CFerramenta::OnKeyDown(CDesenhoDoc* pDoc, CDC *pDC, UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if ( ! m_bTracando ) return ;

	if ( m_tipo == TEXTO )
	{
		// salva o texto e o objeto
		if ( nChar == VK_RETURN ) 
		{
			m_bTracando = FALSE; 
			if ( m_pObjDesTemp ) 
				pDoc->Add(m_pObjDesTemp); 
			m_pObjDesTemp = NULL; 

		}
		// abandona o texto e o objeto
		// TODO: isto pode ser implementado para os outros tipos de desenho!
		else if ( nChar == VK_ESCAPE ) 
		{			
			m_bTracando = FALSE; 

			// apaga o que estava escrito
			//pDC->SetROP2(R2_NOTXORPEN); 			
			m_pObjDesTemp->UnDraw(pDC) ;
			((CTexto *)m_pObjDesTemp)->ClearTexto() ;

			m_pObjDesTemp = NULL;  
		}

		// escreve o caracter
		else if ( m_pObjDesTemp )	
		{
			// inclui o caracter
			((CTexto *)m_pObjDesTemp)->SetTexto(nChar) ;
			m_pObjDesTemp->Draw(pDC) ;
		}
	}
}

// EOF


