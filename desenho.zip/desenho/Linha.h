// Linha.h: interface for the CLinha class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINHA_H__5F4DCF2A_2A7D_403D_B4C7_FA479D27EF81__INCLUDED_)
#define AFX_LINHA_H__5F4DCF2A_2A7D_403D_B4C7_FA479D27EF81__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ObjDes.h"

class CLinha : public CObjDes  
{
public:
	CLinha();
	virtual ~CLinha();
	void SetP1(CPoint p);
	CPoint GetP1();
	void SetP2(CPoint p);
	CPoint GetP2();
	void Draw(CDC *pDC);
	void UnDraw(CDC *pDC);
    virtual void Serialize(CArchive &ar);
    DECLARE_SERIAL(CLinha); 

};

#endif // !defined(AFX_LINHA_H__5F4DCF2A_2A7D_403D_B4C7_FA479D27EF81__INCLUDED_)
