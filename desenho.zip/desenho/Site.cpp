// Site.cpp: implementation of the CSite class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Site.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSite::CSite()
{

}


CSite::CSite(CPoint p)
{
	p1 = p ;
	p2 = p ;
}


CSite::~CSite()
{

}
