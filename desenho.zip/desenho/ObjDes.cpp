// ObjDes.cpp: implementation of the CObjDes class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "ObjDes.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CObjDes::CObjDes(UINT largura, COLORREF cor)
{
	m_crCor = cor ;
	m_nLargura = largura ;
}

CObjDes::~CObjDes()
{

}

void CObjDes::SetarCor(COLORREF cor) 
{ 
	m_crCor = cor ; 
}

COLORREF CObjDes::GetCor() {
	return  m_crCor ; 
}

void CObjDes::SetarLargura(UINT largura) 
{
	m_nLargura = largura ;
}
UINT CObjDes::GetLargura() 
{	
	return m_nLargura;
}

void CObjDes::SetP1(CPoint p)
{
}

CPoint CObjDes::GetP1()
{
	return p1 ;
}

void CObjDes::SetP2(CPoint p)
{
}

CPoint CObjDes::GetP2()
{
	return p2 ;
}


void CObjDes::Draw(CDC *pDC) {}
void CObjDes::UnDraw(CDC *pDC) {}


// EOF*