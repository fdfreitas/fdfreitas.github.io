// Delaunay.h: interface for the CDelaunay class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DELAUNAY_H__80A8AA94_070F_426B_B914_898D754558DE__INCLUDED_)
#define AFX_DELAUNAY_H__80A8AA94_070F_426B_B914_898D754558DE__INCLUDED_

#include "DesenhoDoc.h"
#include "CTimer\src\CTimer.h"

#include "Plane.h"
#include "EventQueue.h"
#include "Sweepline.h"
#include "Beachline.h"
#include "Edge.h"
#include "Vertex.h"
#include "Facet.h"

#include <list>

using namespace std ;


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


//typedef CSite	CPonto ;

class CDelaunay : public CTimer  
{
public:

	CDelaunay();
	virtual ~CDelaunay();
	void SetDC(CDC *pdc);
	void SetDoc(CDesenhoDoc *pdoc);
	void Run();
	void Suspend();
	void Reset();
	void StepY();
	void StepEvent();
	void Notify(void);

	// desenhos...
	void Draw();
	void UnDraw();
	void ReDraw();
	void DrawPlane();
	void UnDrawPlane();
	void DrawVoronoi();
	void DrawDelaunay();

	void DrawEdges();
	void UnDrawEdges();
	void DrawVertices();

	// Manipulaccao das estruturas de dados e outros...
	void InitEventQueue (void);
	void ClearEventQueue (void);
//	void PromoteHalfInfiniteEdges();
//	void SetEdgeBounds(CEdge *e);
//	DPoint CDelaunay::PlaneIntersection(CEdge *e);
//	DPoint LineIntersection(DPoint p1, DPoint p2, CPoint p3, CPoint p4);

	void PromoteOpenEdges();
	void PromoteVertex(CVertex *v, CEdge *edge);
	int ExtrapoledQuadrant(CVertex *v, double A, double B);


	// modalidades de desenho
	void SetShowVoronoi();
	void SetShowDelaunay();
	void SetShowBeach();
	void SetShowCircle();

protected:
	CDesenhoDoc		*pDoc ;	
	CDC				*pDC ;		

	int				Y ;	

	// Estruturas de dados do Plane Sweep do Fortune
	CSweepLine				SweepLine ;		// Sweep Line
	CEventQueue				EventQueue ;	// Fila de eventos
	CBeachLine				BeachLine ;		// Beach Line 

	// Estruturas do Diagrama de Voronoi
	list<CEdge> EdgeList ;
	list<CVertex> VertexList ;
	list<CFacet> FacetList ;

	// Limites do plano: de (Upper Left a (Lower Right)
	CPlane *P;								// Plano ....

	bool show_voronoi ;
	bool show_delaunay ;
	bool show_beach ;
	bool show_circle ;

};

#endif // !defined(AFX_DELAUNAY_H__80A8AA94_070F_426B_B914_898D754558DE__INCLUDED_)


// EOF