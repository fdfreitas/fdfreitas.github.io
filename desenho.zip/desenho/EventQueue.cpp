// EventQueue.cpp: implementation of the CEventQueue class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "EventQueue.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEventQueue::CEventQueue()
{

}

CEventQueue::~CEventQueue()
{

}

bool CEventQueue::Empty()
{
	return 	evtq.empty() ;
}

void CEventQueue::Push(CEvt &e)
{
	evtq.push(e) ;
}

CEvt& CEventQueue::Top ()
{
	return evtq.top() ;
}

void CEventQueue::Pop ()
{
	evtq.pop() ;
}

int CEventQueue::Size()
{
	return evtq.size();
}


// @@ Remove um determinado Evento de Circulo 
void CEventQueue::RemoveForEvtCircle(CObjDes *e)
{
	// Eh assim que se deleta um elemento de um priority_queue???

	CEvt evt ;
	priority_queue<CEvt> evtq_  ;

	while ( ! evtq.empty() ) 
	{
		evt = evtq.top();
		evtq.pop();				

		if ( evt.GetEvt() == e )
		{
			if ( evt.IsCircleEvt() )
			{
				CEvtCircle *c = (CEvtCircle *) evt.GetEvt();
				break;
			}				
		}
		evtq_.push(evt) ;
	}

	while ( ! evtq_.empty()  )
	{
		evtq.push(evtq_.top());
		evtq_.pop();		
	}
}


// @@ Remove todos os Eventos de Circulo contendo um determinado Arco
void CEventQueue::RemoveEvtCircleForArc(CParArc *a)
{
	// Eh assim que se deleta um elemento de um priority_queue???
	CEvt evt ;
	priority_queue<CEvt> evtq_  ;

	while ( ! evtq.empty() ) 
	{
		evt = evtq.top();
		evtq.pop();				

		if ( evt.IsCircleEvt() )
		{
			CEvtCircle *c = (CEvtCircle *) evt.GetEvt();
			if ( c->GetArco() == a )
				c->UnDraw();
				
			else
				evtq_.push(evt) ;
		}
		else
			evtq_.push(evt) ;

	}

	while ( ! evtq_.empty()  )
	{
		evtq.push(evtq_.top());
		evtq_.pop();		
	}
}


void CEventQueue::Clear()
{
	while ( ! Empty() )
		Pop() ;
}


// EOF 