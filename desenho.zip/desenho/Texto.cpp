// Texto.cpp: implementation of the CTexto class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"
#include "Texto.h"
#include "Afxwin.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTexto::CTexto()
{
	texto.Empty() ;
}

CTexto::~CTexto()
{
}

void CTexto::SetP1(CPoint p)
{
	p1 = p ;
}

void CTexto::SetTexto(CString s)
{
	texto = s ;
}

void CTexto::SetTexto(UINT c)
{
	texto += c ;
}


void CTexto::ClearTexto()
{
	texto.Empty() ; 
}

void CTexto::Draw(CDC *pDC)
{
	// desenha o texto no ponto
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 
	
	/* TODO - Usar a funccao correta. Tambem melhorar a escrita do texto */

	int char_height = 12; 

	pDC->SetROP2(R2_COPYPEN); 

	pDC->TextOut(p1.x, p1.y - char_height, texto, strlen (texto) );		

	pDC->SelectObject(pOldPen); 
}

void CTexto::UnDraw(CDC *pDC)
{
	// desenha o texto no ponto
	CPen pen(PS_SOLID,m_nLargura,m_crCor); 
	CPen *pOldPen = (CPen *) pDC->SelectObject(&pen); 
	
	/* TODO - Usar a funccao correta. Tambem melhorar a escrita do texto */

	pDC->SetROP2(R2_NOTXORPEN); 

	int char_height = 12; 

	pDC->TextOut(p1.x, p1.y - char_height, texto, strlen (texto) );		
	pDC->TextOut(p1.x, p1.y - char_height, texto, strlen (texto) );		

	pDC->SelectObject(pOldPen); 
}


IMPLEMENT_SERIAL(CTexto,CObject,1);
void CTexto::Serialize(CArchive &ar) {

    CObject::Serialize(ar);
    if(ar.IsStoring() ) {

	   ar << (ULONG) m_crCor << m_nLargura;
       ar << (ULONG) p1.x << p1.y ; 
       ar << texto ; 

    } 
	else 
	{ 
       ar >> (ULONG) m_crCor ;
	   ar >> m_nLargura;
	   ar >> p1.x ;
	   ar >> p1.y ;
	   ar >> texto ;
	   	   
    } 
}

// EOF