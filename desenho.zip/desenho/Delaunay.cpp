// Delaunay.cpp: implementation of the CDelaunay class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Desenho.h"

#include "Delaunay.h"
#include "ObjDes.h"
#include "EvtSite.h"
#include "EvtCircle.h"
#include "evt.h"

#include "typeinfo.h"
#include "AfxWin.h"
#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CDelaunay::CDelaunay()
{
	show_voronoi  = true;
	show_delaunay = true;
	show_beach    = false;
	show_circle   = false;

	BeachLine.SetShowCircle(show_circle) ;
	BeachLine.SetShowBeach(show_beach) ;
}

CDelaunay::~CDelaunay()
{
	delete P ;
}

void CDelaunay::SetDC(CDC *pdc)
{
	CPoint ul; 
	CPoint lr; 

#if 0
	ul.x = 0;
	ul.y = 0;
	
	lr.x = 800;
	lr.y = 400;
#endif
				
#if 1
	ul.x = 5;
	ul.y = 5;
	
	lr.x = 725;
	lr.y = 415;
#endif

	P = new CPlane(ul, lr, pdc);
	
	CRect rect = CRect (P->UL.x, P->UL.y, P->LR.x, P->LR.y) ;
		
	//P->pDC->SetBoundsRect(&rect,DCB_ACCUMULATE ) ;
	//P->pDC->SetBoundsRect(&rect,DCB_ENABLE | DCB_ACCUMULATE) ;

//	GetWindowRect(P->pDC->GetWindow(), &rect);
	CPoint point = P->pDC->GetViewportOrg() ;
//	P->pDC->SetViewportOrg(P->UL) ;
//	P->pDC->SetWindowOrg(P->UL) ;

	Y = P->UL.y ;
	SweepLine.SetPlane(P) ;
	BeachLine.SetPlane(P) ;

}

void CDelaunay::SetDoc(CDesenhoDoc *pdoc)
{
	pDoc = pdoc;
}

void CDelaunay::SetShowVoronoi()
{
	show_voronoi  = ! show_voronoi ;
}	
void CDelaunay::SetShowDelaunay()
{
	show_delaunay = ! show_delaunay;
}
void CDelaunay::SetShowBeach()
{
	show_beach = ! show_beach;
	BeachLine.SetShowBeach(show_beach) ;

}
void CDelaunay::SetShowCircle()
{
	show_circle   = ! show_circle;
	BeachLine.SetShowCircle(show_circle) ;
}

void CDelaunay::InitEventQueue()
{
	// Ajusta o apontador de BeachLine para a EventQueue, uma vez
	// que a BeachLine necessita manipula-la nos eventos de Circulo

	BeachLine.Setup(&EventQueue, &EdgeList, &VertexList, &FacetList) ;

	// Inicializa a fila de eventos com os eventos de Site

	 // inclui todos os eventos na lista
	ASSERT_VALID(pDoc);

	UINT n = pDoc->GetSize(); 
	
	for( UINT i=0; i < n; i++ ) 
	{	
		CObject *obj = pDoc->Get(i) ;
		const type_info& t = typeid(*obj) ;     
		string s = t.name() ;

		if ( ! strcmp (s.c_str(), "class CPonto") ) 
		{
			CEvtSite *esite = new CEvtSite ( ((CPonto *) obj)->GetP1() ) ; 			
			CEvt *evt    = new CEvt (*esite) ; 

			EventQueue.Push( *evt  /*(CEvtSite) *esite*/ ); 

			// NAO PODE!!!!! delete esite, pois evt guarda um apontador para ele ;
			delete evt ;
		}
	}	
}

void CDelaunay::ClearEventQueue()
{
	UnDraw();

	EventQueue.Clear() ;
	SweepLine.Clear() ;
	BeachLine.Clear() ;

	EdgeList.clear() ;
	VertexList.clear() ;
	FacetList.clear() ;

	P->pDC->GetWindow()->Invalidate();

}


void CDelaunay::Run()
{

	// Inicia  o Plane Sweep!!!
	ClearEventQueue() ;	
	InitEventQueue() ;

	Start (1, FALSE) ;
}

void CDelaunay::Suspend()
{
	Stop () ;
}

void CDelaunay::Reset()
{
	Y = P->UL.y ;

	SweepLine.Clear();
	EventQueue.Clear();
	BeachLine.Clear();
	EdgeList.clear();
	VertexList.clear();
	FacetList.clear();

	Stop () ;
}


void CDelaunay::StepY()
{
	Stop() ;
	Notify ();
}

void CDelaunay::StepEvent()
{
;
}


void CDelaunay::Notify(void)
{
	CEvt e;
	int y ;

#define PIXEL	1

	//--- modo do step da varredura  por EVENTO ou PIXEL---//
	if ( PIXEL )
		Y++ ;
	else
	{
		// recupera o evento do topo da fila de eventos
		e = EventQueue.Top() ;
		y = e.GetY(); 
		// pula para o Y do evento
		Y = y; 
	}

	// atualiza o Y das estruturas...	
	SweepLine.SetY(Y) ;		
	BeachLine.SetY(Y);

	while ( 1 ) 
	{
		//--- retira o evento do topo da fila de eventos ---//
		if ( EventQueue.Empty() )
			break ;
		
		e = EventQueue.Top() ;
		y = e.GetY(); 

		// A Sweep Line atingiu um evento?
		if ( Y == y )
		{
			// Evento de Site
			if ( e.IsSiteEvt() )		
			{
				BeachLine.HandleSiteEvent ( (CEvtSite *) e.GetEvt() );
				//Beep(1000, 50) ;
			}
			// Evento de Circulo
			else if ( e.IsCircleEvt() )		
			{
				BeachLine.HandleCircleEvent ( (CEvtCircle *) e.GetEvt() ) ;
				//Beep(500, 50) ;
			}
		}

		else
		{
			// nao ha mais eventos neste Y 
			break ; 

		}

		Draw();
	}

	BeachLine.CalcBreakPoints();

//	BeachLine.Debug("Dentro do NOTIFY - SAIDA DO LOOP");
//	BeachLine.Debug();

	Draw();	
	
	// Condiccao de parada: todos os BPs ja passaram do limite inferior do plano
	if ( BeachLine.CanStopSweep() ) 
	{
		Stop();		

		PromoteOpenEdges();
		Draw();
	}
}


///////////////////////////////////////////////////////////////////////////////
// @@ PromoteOpenEdges()
// Cria vertices nos limites do planos para os edges abertos.
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::PromoteOpenEdges()
{
	list<CEdge>::iterator first = EdgeList.begin();
	list<CEdge>::iterator last  = EdgeList.end();
	list<CEdge>::iterator found = first ;


	CVertex *v ;
	CEdge *e;

	while ( found != last )
	{
		e = found->This() ;
		if ( e->IsDrawable() )
		{
		  	if ( e->GetOrig() == NULL )
			{
				v = BeachLine.AddVertex(e->GetPointOrig(), e);
				e->SetOrig(v) ;
				PromoteVertex (v, e) ;
				e->SetOrig(v) ;
				e->SetTwin(e->GetTwin());
			} 
			if ( e->GetDest() == NULL )
			{
				v = BeachLine.AddVertex(e->GetPointDest(), e);
				e->SetDest(v) ;
				PromoteVertex (v, e) ;
				e->SetDest(v) ;
				e->SetTwin(e->GetTwin());
			} 
		}

		found++;
	}
}

///////////////////////////////////////////////////////////////////////////////
// @@ PromoteVertex()
// Ajusta o vertice para dentro dos limites do plano.
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::PromoteVertex(CVertex *v, CEdge *edge)
{
	pair<DPoint, DPoint> pontos ;
	DPoint p;
	double A, B;

 	// acha a equaccao do edge: y = Ax + B, x = (y - B)/A
	// A = (y2 - y1) / (x2 - x1)
	// B = y - Ax 
	pontos = edge->GetPoints();
	// A
	if ( sqrt (pow (pontos.second.x - pontos.first.x, 2.0)) < DBL_MIN_ERROR )
	{
		A = MAX_DOUBLE;
		B = MIN_DOUBLE; 
	}
	else if ( pontos.first.y  == MIN_DOUBLE )
	{
		A = MAX_DOUBLE;
		B = MIN_DOUBLE; 
	}
	else if ( pontos.first.y  == MIN_DOUBLE )
	{
		A = MAX_DOUBLE;
		B = MIN_DOUBLE; 
	}
	else if ( pontos.second.y  == MAX_DOUBLE )
	{
		A = MAX_DOUBLE;
		B = MIN_DOUBLE; 
	}
	else if ( pontos.second.y  == MIN_DOUBLE )
	{
		A = MIN_DOUBLE;
		B = MIN_DOUBLE; 
	}
	else
	{
		A = (pontos.second.y - pontos.first.y)/(pontos.second.x - pontos.first.x); 
		B = pontos.first.y - (A*pontos.first.x); 
	}

	// calcula o novo ponto do vertice
	switch (ExtrapoledQuadrant(v, A, B))
	{
		// O vertice esta dentro do plano!
		case 0:
			return;
		// quadrante 1
		case 1:
			p.x = (double) P->UL.x;
			p.y = A*p.x + B ;	
			break;
		// quadrante 2
		case 2:
			p.y = (double) P->UL.y ;
			if ( A == MAX_DOUBLE )
				p.x = pontos.first.x;
			else
				p.x = (p.y - B)/A;
			break;
		// quadrante 3
		case 3:
			p.x = (double) P->LR.x;
			p.y = A*p.x + B ;
			break;
		// quadrante 4
		case 4:
			p.y = (double) P->LR.y ;
			if ( A == MAX_DOUBLE )
				p.x = pontos.first.x;
			else
				p.x = (p.y - B)/A;
			break;			
	}
	// ajusta o vertice
	v->SetPoint(p) ;
}

///////////////////////////////////////////////////////////////////////////////
// @@ ExtrapoledQuadrant()
// Retorna o quadrante extrapolado pelo vertice.
//       2     
//   +-------+
//   |       |
// 1 |   0   | 3
//   |       |
//   +-------+
//       4
///////////////////////////////////////////////////////////////////////////////
int CDelaunay::ExtrapoledQuadrant(CVertex *v, double A, double B)
{
	double x, y ;

	// Quadrante 1 
	if ( v->GetPoint().x < P->UL.x )
	{
		x = P->UL.x ;
		y = A*x + B;
		if ( y >= (double) P->UL.y && y <= (double) P->LR.y )
			return 1 ;
	}
	// Quadrante 2 
	if ( v->GetPoint().y < P->UL.y )
	{
		y = P->UL.y;
		if ( A == MAX_DOUBLE || A == MIN_DOUBLE )
			x = v->GetPoint().x ;
		else
			x = (y - B)/A ;
		if ( x >= (double) P->UL.x && x <= (double) P->LR.x )
		    return 2 ;
	}
	// Quadrante 3 
	if ( v->GetPoint().x > P->LR.x )
	{
		x = P->LR.x ;
		y = A*x + B;
		if ( y >= (double) P->UL.y && y <= (double) P->LR.y )
			return 3 ;
	}
	// Quadrante 4 
	if ( v->GetPoint().y > P->LR.y )
	{
		y = P->LR.y;
		if ( A == MAX_DOUBLE || A == MIN_DOUBLE)
			x = v->GetPoint().x;
		else
			x = (y - B)/A ;
		if ( x >= (double) P->UL.x && x <= (double) P->LR.x )
		    return 4 ;
	}

	return 0 ;
}

///////////////////////////////////////////////////////////////////////////////
// @@ Draw
// Desenha tudo!
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::Draw()
{
	if ( show_voronoi )
		DrawVoronoi();

	if ( show_delaunay )
		DrawDelaunay();
	
	if  ( show_beach  )
		BeachLine.Draw();	
}

///////////////////////////////////////////////////////////////////////////////
// @@ UnDraw
// Apaga tudo!
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::UnDraw()
{
	if  ( show_beach  )
		BeachLine.UnDraw();	
	//UnDrawEdges();	
}

///////////////////////////////////////////////////////////////////////////////
// @@ ReDraw
// Redesenha tudo!
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::ReDraw()
{
	UnDraw();
	DrawPlane();
	Draw();
}

///////////////////////////////////////////////////////////////////////////////
// @@ DrawPlane
// Desenha os bounds do plano
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::DrawPlane()
{

	P->pDC->SetROP2(R2_NOTXORPEN); 
	P->pDC->Rectangle(P->UL.x, P->UL.y, P->LR.x, P->LR.y)  ;
}

///////////////////////////////////////////////////////////////////////////////
// @@ UnDrawPlane
// Apaga os bounds do plano
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::UnDrawPlane()
{

	P->pDC->SetROP2(R2_NOTXORPEN); 
	P->pDC->Rectangle(P->UL.x, P->UL.y, P->LR.x, P->LR.y)  ;
}

///////////////////////////////////////////////////////////////////////////////
// @@ DrawEdges
// Desenha os edges de Voronoi
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::DrawEdges()
{
	list<CEdge>::iterator first = EdgeList.begin();
	list<CEdge>::iterator last  = EdgeList.end();

	while ( first != last )
	{
		first->Draw() ;
		first++;
	}
}

///////////////////////////////////////////////////////////////////////////////
// @@ UnDrawEdges
// Apaga os edges de Voronoi
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::UnDrawEdges()
{
	list<CEdge>::iterator first = EdgeList.begin();
	list<CEdge>::iterator last  = EdgeList.end();

	while ( first != last )
	{
		first->UnDraw() ;
		first++;
	}
}


///////////////////////////////////////////////////////////////////////////////
// @@ DrawVoronoi()
// Desenha o diagrama de Voronoi a partir da DECL concluida
//
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::DrawVoronoi()
{
	list<CVertex>::iterator first = VertexList.begin();
	list<CVertex>::iterator last  = VertexList.end();

	// OBS: O correto eh acessar os Facets e desenhar os vertices e 
	// edges encadeados. Porem, ainda nao terminei as verificaccoes do 
	// encadeamento dos edges, etnao desenho os edges e vertices em separado,
	// o que para efeitop de desenho apenas nao eh ruim!

	// desenha os vertices
	while ( first != last )
	{
		CVertex *v ;	
		v = first->This();

		v->Draw() ;
		first++;
	}

	DrawEdges();
}


///////////////////////////////////////////////////////////////////////////////
// @@ DrawDelaunay()
// Desenha a triangulaccao de Delaunay
//
///////////////////////////////////////////////////////////////////////////////
void CDelaunay::DrawDelaunay()
{
	CEdge *e;
	CEvtSite *sl = NULL , *sr = NULL ;

	list<CEdge>::iterator first = EdgeList.begin();
	list<CEdge>::iterator last  = EdgeList.end();
	
	while ( first != last )
	{
		e = first->This() ;
		
		// Pego apenas um edge de cada (nao ao twin)
		if ( e->IsDrawable() )
		{
			sl = e->GetLeftSite() ;

			if ( e->GetTwin() != NULL )
				sr = e->GetTwin()->GetLeftSite() ;

			if ( sl != NULL && sr != NULL )
			{
				P->pDC->SetROP2(R2_COPYPEN); 

				P->pDC->MoveTo(sl->GetP1()) ;
				P->pDC->LineTo (sr->GetP1()) ;
			}
		}

		first++;
	}
}


// EOF
