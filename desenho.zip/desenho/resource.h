//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Desenho.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DESENHTYPE                  129
#define ID_TOOLS_FREEHAND               32771
#define ID_TOOLS_POLIGONAL              32772
#define ID_TOOLS_RETANGULO              32773
#define ID_TOOLS_CIRCULO                32774
#define ID_TOOLS_TEXTO                  32775
#define ID_TOOLS_LINHA                  32776
#define ID_TOOLS_REFRESH                32777
#define ID_BUTTON32788                  32788
#define ID_TOOLS_PONTO                  32789
#define ID_DELAUNAY_                    32790
#define ID_DELAUNAY_START               32794
#define ID_DELAUNAY_STOP                32795
#define ID_DELAUNAY_RESET               32796
#define ID_DELAUNAY_CLEAR               32797
#define ID_DELAUNAY_PIXEL_STEP          32798
#define ID_DELAUNAY_Y_STEP              32799
#define ID_DELAUNAY_EVENT_STEP          32800
#define ID_DELAUNAY_SHOW_VORONOI        32801
#define ID_DELAUNAY_SHOW_DELAUNAY       32802
#define ID_DELAUNAY_SHOW_BEACH          32803
#define ID_DELAUNAY_SHOW_CIRCLE         32804

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32805
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
