// EvtCircle.h: interface for the EvtCircle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EVTCIRCLE_H__FFD1DE2B_AC35_4674_9326_1A01C84B6940__INCLUDED_)
#define AFX_EVTCIRCLE_H__FFD1DE2B_AC35_4674_9326_1A01C84B6940__INCLUDED_


#include "Circulo.h"
#include "Evt.h"
#include "Ponto.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "plane.h"

class CParArc;


class CEvtCircle : public CCirculo  
{
public:
	CEvtCircle();
	virtual ~CEvtCircle();

	CEvtCircle(CObjDes *e);
	CEvtCircle(CPlane *p, CPoint a, CPoint b);
	CEvtCircle(CPlane *p, double x0, double y0, double r);

	void SetArco(CParArc *a);
	CParArc *GetArco();
	void CEvtCircle::Draw();
	void CEvtCircle::UnDraw();

	// Seccao NICE CLASS!!! 
	CEvtCircle(const CEvtCircle& c) 
	{		
		p1 = c.p1 ;
		p2 = c.p2 ;
		m_crCor = c.m_crCor ;
		m_nLargura = c.m_nLargura;
		arco = c.arco;
	}

	CEvtCircle& operator= (const CEvtCircle& c) 
	{
		p1 = c.p1 ;
		p2 = c.p2 ;
		m_crCor = c.m_crCor ;
		m_nLargura = c.m_nLargura;
		arco = c.arco;

		return *this;
	}

	bool operator< (CEvtCircle const &c) const
	{
		return ( p1.y > c.p1.y ) ;	
	}

	bool operator== (CEvtCircle const &c) const
	{
		return ( p1.x == c.p1.x && p1.y == c.p1.y ) ;	
	}

	bool operator!= (CEvtCircle const &c) const
	{
		return ( ! (p1.x == c.p1.x && p1.y == c.p1.y) ) ;	
	}
	// fim NICE CLASS!!!!  


protected:

	CPlane *Plano;		// Plano do diagrama...
	CParArc *arco ;		// Arco que gerou o Evento de circulo
};

#endif // !defined(AFX_EVTCIRCLE_H__FFD1DE2B_AC35_4674_9326_1A01C84B6940__INCLUDED_)

// EOF